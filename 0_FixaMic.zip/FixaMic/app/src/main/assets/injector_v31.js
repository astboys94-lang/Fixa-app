(function() {
    'use strict';

    if (window.__FIXA_MIC_INIT_STARTED__) return;
    window.__FIXA_MIC_INIT_STARTED__ = true;

    // ===== ALL FEATURES PRESERVED =====
    const PARAMS = {
        masterGain: 0.0,
        inputBoost: 0.0,
        width: 0.0,
        pitch: 50,
        reverb: 0,
        reverbType: 'hall',
        eqBass: 50,
        eqMid: 50,
        eqTreble: 50,
        gateThreshold: -40,
        voiceChanger: 'none',
        formant: 1.0,
        distortion: 0,
        noiseReduction: 0,
        vadEnabled: false,
        vadThreshold: -45,
        duckingEnabled: false,
        duckingReduction: 10,
        voiceProfile: 'auto',
        theme: 'Default',
        quickActionsEnabled: true,
        statsEnabled: true
    };

    const VOICE_PRESETS = {
        'none':     { pitch: 50, formant: 1.0, distortion: 0,   reverb: 0  },
        'robot':    { pitch: 30, formant: 0.8, distortion: 0.3,  reverb: 10 },
        'chipmunk': { pitch: 75, formant: 1.5, distortion: 0,   reverb: 5  },
        'alien':    { pitch: 40, formant: 1.2, distortion: 0.2,  reverb: 40 },
        'demon':    { pitch: 25, formant: 0.7, distortion: 0.5,  reverb: 30 },
        'giant':    { pitch: 30, formant: 0.6, distortion: 0.1,  reverb: 50 },
        'echo':     { pitch: 50, formant: 1.0, distortion: 0,   reverb: 70 },
        'helium':   { pitch: 70, formant: 1.3, distortion: 0,   reverb: 10 }
    };

    const VOICE_PROFILES = {
        'auto':          {},
        'Male Deep':     { eqBass: 65, eqMid: 45, eqTreble: 35, gateThreshold: -45 },
        'Male Medium':   { eqBass: 55, eqMid: 50, eqTreble: 45, gateThreshold: -45 },
        'Male High':     { eqBass: 45, eqMid: 55, eqTreble: 55, gateThreshold: -40 },
        'Female Low':    { eqBass: 50, eqMid: 55, eqTreble: 55, gateThreshold: -40 },
        'Female Medium': { eqBass: 40, eqMid: 55, eqTreble: 65, gateThreshold: -45 },
        'Female High':   { eqBass: 35, eqMid: 50, eqTreble: 75, gateThreshold: -45 },
        'Headset Mic':   { eqBass: 45, eqMid: 65, eqTreble: 55, gateThreshold: -50 },
        'Studio Mic':    { eqBass: 55, eqMid: 50, eqTreble: 50, gateThreshold: -60 }
    };

    const PRESETS = {
        'Default':      {},
        'Bass Boost':   { masterGain: 5, eqBass: 80, eqMid: 50, eqTreble: 40 },
        'Voice Clarity':{ gateThreshold: -50, eqBass: 40, eqMid: 65, eqTreble: 70 },
        'Wide Stereo':  { width: 70, reverb: 15 },
        'Radio Effect': { eqBass: 30, eqMid: 70, eqTreble: 30, width: 20, reverb: 30 },
        'Podcast':      { gateThreshold: -55, eqBass: 45, eqMid: 60, eqTreble: 65 },
        'Streamer':     { masterGain: 3, gateThreshold: -50, eqMid: 65, width: 40 },
        'ASMR':         { gateThreshold: -70, eqBass: 40, eqMid: 50, eqTreble: 70, reverb: 10 }
    };

    // ===== AUDIO CONTEXT =====
    window.DiscordContext = null;
    const NativeAudioContext = window.AudioContext || window.webkitAudioContext;
    let pendingContextResolvers = [];
    let contextReady = false;
    let uiVisible = false;
    let animationFrame = null;
    let lastFrameTime = 0;
    const FRAME_TIME = 1000 / 30;

    const createContextOnGesture = () => {
        if (contextReady) return;
        contextReady = true;
        window.removeEventListener('click', createContextOnGesture, { capture: true });
        window.removeEventListener('keydown', createContextOnGesture, { capture: true });
        window.removeEventListener('touchstart', createContextOnGesture, { capture: true });
        if (window.DiscordContext && window.DiscordContext.state === 'suspended') {
            window.DiscordContext.resume().then(() => {
                pendingContextResolvers.forEach(r => r());
                pendingContextResolvers = [];
            });
        }
    };
    window.addEventListener('click', createContextOnGesture, { capture: true });
    window.addEventListener('keydown', createContextOnGesture, { capture: true });
    window.addEventListener('touchstart', createContextOnGesture, { capture: true });

    window.AudioContext = function() {
        const ctx = new NativeAudioContext({ latencyHint: 'interactive', sampleRate: 48000 });
        window.DiscordContext = ctx;
        return ctx;
    };
    window.AudioContext.prototype = NativeAudioContext.prototype;

    // ===== AUDIO WORKLET (PRESERVED EXACTLY) =====
    const WORKLET_CODE = `
        class SonicEngine extends AudioWorkletProcessor {
            static get parameterDescriptors() {
                return [
                    { name: 'gain', defaultValue: 1.0 },
                    { name: 'boost', defaultValue: 1.0 },
                    { name: 'width', defaultValue: 0.0, maxValue: 1 },
                    { name: 'pitch', defaultValue: 1.0, minValue: 0.5, maxValue: 2.0 },
                    { name: 'reverb', defaultValue: 0.0, maxValue: 1 },
                    { name: 'eqBass', defaultValue: 1.0, minValue: 0.5, maxValue: 2.0 },
                    { name: 'eqMid', defaultValue: 1.0, minValue: 0.5, maxValue: 2.0 },
                    { name: 'eqTreble', defaultValue: 1.0, minValue: 0.5, maxValue: 2.0 },
                    { name: 'gateThreshold', defaultValue: 0.01, maxValue: 0.1 },
                    { name: 'formant', defaultValue: 1.0, minValue: 0.5, maxValue: 2.0 },
                    { name: 'distortion', defaultValue: 0.0, maxValue: 1 },
                    { name: 'noiseReduction', defaultValue: 0.0, maxValue: 1 },
                    { name: 'ducking', defaultValue: 0.0, maxValue: 1 }
                ];
            }
            constructor() {
                super();
                this.bufSize = 4096;
                this.bufL = new Float32Array(this.bufSize);
                this.bufR = new Float32Array(this.bufSize);
                this.writePos = 0;
                this.readPos = 0.0;
                this.reverbBuffer = new Float32Array(24000);
                this.reverbPos = 0;
                this.gateEnvelope = 0;
                this.peak = 0;
            }
            process(inputs, outputs, parameters) {
                const input = inputs[0];
                const output = outputs[0];
                if (!input || input.length === 0) return true;
                const gain = parameters.gain[0];
                const boost = parameters.boost[0];
                const width = parameters.width[0];
                const pitch = parameters.pitch[0];
                const reverbAmt = parameters.reverb[0];
                const eqBass = parameters.eqBass[0];
                const eqMid = parameters.eqMid[0];
                const eqTreble = parameters.eqTreble[0];
                const gateThresh = parameters.gateThreshold[0];
                const formant = parameters.formant[0];
                const distortion = parameters.distortion[0];
                const noiseReduction = parameters.noiseReduction[0];
                const ducking = parameters.ducking[0];
                const inL = input[0];
                const inR = input[1] || input[0];
                const outL = output[0];
                const outR = output[1] || output[0];
                const len = inL.length;
                let peak = 0;
                for (let i = 0; i < len; i++) {
                    let L = inL[i] * boost;
                    let R = inR[i] * boost;
                    if (noiseReduction > 0) {
                        L *= (1 - noiseReduction * 0.5);
                        R *= (1 - noiseReduction * 0.5);
                    }
                    const level = Math.abs(L + R) * 0.5;
                    if (level > gateThresh) {
                        this.gateEnvelope = Math.min(1, this.gateEnvelope + 0.01);
                    } else {
                        this.gateEnvelope = Math.max(0, this.gateEnvelope - 0.001);
                    }
                    L *= this.gateEnvelope;
                    R *= this.gateEnvelope;
                    L = L * eqMid + (L - L * 0.98) * eqTreble;
                    R = R * eqMid + (R - R * 0.98) * eqTreble;
                    if (distortion > 0) {
                        L = Math.tanh(L * (1 + distortion * 3));
                        R = Math.tanh(R * (1 + distortion * 3));
                    }
                    if (reverbAmt > 0.01) {
                        L += this.reverbBuffer[this.reverbPos] * reverbAmt * 0.5;
                        R += this.reverbBuffer[(this.reverbPos + 12000) % 24000] * reverbAmt * 0.5;
                        this.reverbBuffer[this.reverbPos] = (L + R) * 0.3;
                        this.reverbPos = (this.reverbPos + 1) % 24000;
                    }
                    this.bufL[this.writePos] = L;
                    this.bufR[this.writePos] = R;
                    this.writePos = (this.writePos + 1) % this.bufSize;
                    L = this.bufL[Math.floor(this.readPos)];
                    R = this.bufR[Math.floor(this.readPos)];
                    this.readPos = (this.readPos + pitch) % this.bufSize;
                    if (width > 0.01) {
                        const mid = (L + R) * 0.5;
                        const side = (L - R) * 0.5 * (1 + width);
                        L = mid + side;
                        R = mid - side;
                    }
                    L *= gain * (1 - ducking * 0.7);
                    R *= gain * (1 - ducking * 0.7);
                    outL[i] = Math.tanh(L);
                    if (output[1]) outR[i] = Math.tanh(R);
                    if ((i & 63) === 0) {
                        peak = Math.max(peak, Math.abs(L), Math.abs(R));
                    }
                }
                if (Math.random() < 0.01) { this.port.postMessage({ peak }); }
                return true;
            }
        }
        registerProcessor('sonic-engine', SonicEngine);
    `;

    // ===== STATS (PRESERVED) =====
    const Stats = {
        speakingTime: 0, speakingStart: null, peakVolume: -60, samples: [],
        update(level) {
            if (!PARAMS.statsEnabled) return;
            this.samples.push(level);
            if (this.samples.length > 100) this.samples.shift();
            if (level > PARAMS.vadThreshold) {
                if (!this.speakingStart) this.speakingStart = Date.now();
            } else if (this.speakingStart) {
                this.speakingTime += (Date.now() - this.speakingStart) / 1000;
                this.speakingStart = null;
            }
            this.peakVolume = Math.max(this.peakVolume, level);
        },
        getStats() {
            const avg = this.samples.reduce((a, b) => a + b, 0) / this.samples.length || -60;
            return {
                speakingTime: this.formatTime(this.speakingTime),
                avgVolume: avg.toFixed(1) + ' dB',
                peakVolume: this.peakVolume.toFixed(1) + ' dB'
            };
        },
        formatTime(s) {
            return Math.floor(s/3600) + 'h ' + Math.floor((s%3600)/60) + 'm ' + Math.floor(s%60) + 's';
        },
        reset() { this.speakingTime = 0; this.peakVolume = -60; this.samples = []; }
    };

    // ===== CORE AUDIO (PRESERVED) =====
    const Core = {
        node: null, analyser: null,
        async inject(stream) {
            let ctx = window.DiscordContext;
            if (!ctx) {
                if (!NativeAudioContext) throw new Error('Web Audio API is unavailable');
                ctx = new NativeAudioContext({ latencyHint: 'interactive', sampleRate: 48000 });
                window.DiscordContext = ctx;
            }
            if (ctx.state === 'suspended') {
                await new Promise(resolve => {
                    if (contextReady) ctx.resume().then(resolve);
                    else pendingContextResolvers.push(() => ctx.resume().then(resolve));
                });
            }
            const source = ctx.createMediaStreamSource(stream);
            const dest = ctx.createMediaStreamDestination();
            this.analyser = ctx.createAnalyser();
            this.analyser.fftSize = 512;
            this.analyser.smoothingTimeConstant = 0.8;
            try {
                const blob = new Blob([WORKLET_CODE], { type: 'application/javascript' });
                const url = URL.createObjectURL(blob);
                await ctx.audioWorklet.addModule(url);
                this.node = new AudioWorkletNode(ctx, 'sonic-engine');
                this.node.port.onmessage = (e) => { if (e.data.peak) UI.updateMeter(e.data.peak); };
                source.connect(this.node);
                this.node.connect(dest);
                this.node.connect(this.analyser);
                this.update();
                UI.setStatus('LIVE');
            } catch (e) {
                source.connect(dest);
            }
            return dest.stream;
        },
        update() {
            if (!this.node) return;
            const p = this.node.parameters;
            const t = window.DiscordContext.currentTime;
            const updates = {
                gain: dbToGain(PARAMS.masterGain),
                boost: dbToGain(PARAMS.inputBoost),
                width: PARAMS.width / 100,
                pitch: Math.pow(2, (PARAMS.pitch - 50) / 25),
                reverb: PARAMS.reverb / 100,
                eqBass: PARAMS.eqBass / 50,
                eqMid: PARAMS.eqMid / 50,
                eqTreble: PARAMS.eqTreble / 50,
                gateThreshold: dbToGain(PARAMS.gateThreshold),
                formant: PARAMS.formant,
                distortion: PARAMS.distortion / 100,
                noiseReduction: PARAMS.noiseReduction / 100,
                ducking: PARAMS.duckingEnabled ? PARAMS.duckingReduction / 20 : 0
            };
            if (VOICE_PRESETS[PARAMS.voiceChanger] && PARAMS.voiceChanger !== 'none') {
                const preset = VOICE_PRESETS[PARAMS.voiceChanger];
                updates.pitch = Math.pow(2, (preset.pitch - 50) / 25);
                updates.formant = preset.formant;
                updates.distortion = preset.distortion;
                updates.reverb = (preset.reverb || 0) / 100;
            }
            Object.entries(updates).forEach(([param, value]) => {
                if (p.has(param)) p.get(param).setTargetAtTime(value, t, 0.05);
            });
        },
        getSpectrum() {
            if (!this.analyser) return new Uint8Array(0);
            const data = new Uint8Array(this.analyser.frequencyBinCount);
            this.analyser.getByteFrequencyData(data);
            return data;
        },
        getWaveform() {
            if (!this.analyser) return new Uint8Array(0);
            const data = new Uint8Array(this.analyser.frequencyBinCount);
            this.analyser.getByteTimeDomainData(data);
            return data;
        }
    };

    function dbToGain(db) { return Math.pow(10, db / 20); }

    const nativeGUM = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    navigator.mediaDevices.getUserMedia = async (constraints) => {
        // Preserve video settings and audio device selection while allowing the extension's
        // own processing chain to handle the microphone signal.
        const safeConstraints = constraints ? { ...constraints } : {};
        if (safeConstraints.audio && typeof safeConstraints.audio === 'object') {
            safeConstraints.audio = {
                ...safeConstraints.audio,
                echoCancellation: false,
                noiseSuppression: false,
                autoGainControl: false
            };
        }
        const originalStream = await nativeGUM(safeConstraints);
        if (!safeConstraints.audio) return originalStream;
        try { return await Core.inject(originalStream); }
        catch (e) {
            console.warn('[FIXA MIC] Audio processing could not start; using original microphone stream.', e);
            return originalStream;
        }
    };

    // ===== PEAK HISTORY =====
    const peakHistory = new Array(64).fill(0);
    let currentMeterPeak = 0;
    let peakHoldVal = 0;
    let peakHoldTimer = 0;

    // ===== KNOB STATE =====
    // Each knob: { id, param, min, max, label, formatFn }
    const KNOBS = [
        { id: 'knob-masterGain', param: 'masterGain', min: 0, max: 100, label: 'MASTER GAIN',
          formatFn: (v) => { const db = Math.round((v - 0)); return (db >= 0 ? '+' : '') + db + ' dB'; } },
        { id: 'knob-inputBoost', param: 'inputBoost', min: 0, max: 100, label: 'PRE-AMP',
          formatFn: (v) => { const db = (v * 0.2).toFixed(1); return (parseFloat(db) >= 0 ? '+' : '') + db + ' dB'; } },
        { id: 'knob-width', param: 'width', min: 0, max: 100, label: 'STEREO WIDTH',
          formatFn: (v) => v + '%' }
    ];

    // ===== UI =====
    const UI = {
        panel: null,
        button: null,
        quickBar: null,
        knobDrags: {},

        init() {
            this.injectCSS();
            this.createButton();
            this.createPanel();
            this.createQuickBar();
            this.bindEvents();
            this.bindKnobs();
            this.startAnimationLoop();

            document.addEventListener('keydown', (e) => {
                if (e.altKey && e.key === 'e') { e.preventDefault(); this.togglePanel(); }
            });
        },

        createButton() {
            this.button = document.createElement('div');
            this.button.id = 'lh-btn';
            this.button.innerHTML =
                '<span class="lh-btn-dot" id="lh-dot"></span>' +
                '<span class="lh-btn-label">FIXA AMPLIFIER</span>' +
                '<span class="lh-btn-status" id="lh-status">IDLE</span>';
            document.body.appendChild(this.button);
            // Do not attach the draggable touch handler to the launcher:
            // its preventDefault() suppressed synthetic click events on phones.
            this.button.setAttribute('role', 'button');
            this.button.setAttribute('tabindex', '0');
            this.button.setAttribute('aria-controls', 'lh-panel');
            this.button.setAttribute('aria-expanded', 'false');
        },

        createQuickBar() {
            this.quickBar = document.createElement('div');
            this.quickBar.id = 'lh-quickbar';
            this.quickBar.innerHTML =
                '<button class="lh-qb-btn" data-action="mute" title="Mute">MIC</button>' +
                '<button class="lh-qb-btn" data-action="voice" title="Voice">VFX</button>' +
                '<button class="lh-qb-btn" data-action="preset" title="Save">SAV</button>' +
                '<button class="lh-qb-btn" data-action="stats" title="Stats">STS</button>';
            document.body.appendChild(this.quickBar);
            this.makeDraggable(this.quickBar);
        },

        createPanel() {
            this.panel = document.createElement('div');
            this.panel.id = 'lh-panel';
            this.panel.style.display = 'none';

            // Build voice preset options
            let voiceOpts = '';
            Object.keys(VOICE_PRESETS).forEach(function(v) {
                voiceOpts += '<option value="' + v + '">' + v.charAt(0).toUpperCase() + v.slice(1) + '</option>';
            });

            // Build voice profile options
            let profileOpts = '';
            Object.keys(VOICE_PROFILES).forEach(function(v) {
                profileOpts += '<option value="' + v + '">' + v + '</option>';
            });

            // Build preset buttons
            let presetBtns = '';
            Object.keys(PRESETS).forEach(function(name) {
                presetBtns += '<button class="lh-preset-btn" data-preset="' + name + '">' + name + '</button>';
            });

            this.panel.innerHTML =
                '<div class="lh-header" id="lh-header">' +
                  '<div class="lh-header-left">' +
                    '<div class="lh-logo-mark"></div>' +
                    '<div class="lh-title-block">' +
                      '<span class="lh-title">FIXA AMPLIFIER</span>' +
                      '<span class="lh-credit">WhatsApp Web • Discord</span>' +
                    '</div>' +
                  '</div>' +
                  '<div class="lh-header-right">' +
                    '<div class="lh-live-badge" id="lh-live">IDLE</div>' +
                    '<button class="lh-close-btn" id="lh-close">&#x2715;</button>' +
                  '</div>' +
                '</div>' +

                '<div class="lh-tabs" id="lh-tabs">' +
                  '<button class="lh-tab active" data-tab="main">Main</button>' +
                  '<button class="lh-tab" data-tab="eq">EQ</button>' +
                  '<button class="lh-tab" data-tab="voice">Voice</button>' +
                  '<button class="lh-tab" data-tab="advanced">Advanced</button>' +
                  '<button class="lh-tab" data-tab="presets">Presets</button>' +
                '</div>' +

                '<div class="lh-body">' +

                  // MAIN TAB
                  '<div class="lh-tab-pane active" data-tab="main">' +
                    // Spectrum
                    '<div class="lh-graph-box">' +
                      '<div class="lh-graph-hdr">' +
                        '<span class="lh-graph-lbl">SPECTRUM ANALYZER</span>' +
                        '<span class="lh-peak-lbl" id="lh-peak-label">— dBFS</span>' +
                      '</div>' +
                      '<canvas id="lh-spectrum" width="352" height="80"></canvas>' +
                      '<div class="lh-hz-scale">' +
                        '<span>20</span><span>100</span><span>500</span><span>1k</span><span>5k</span><span>20k</span>' +
                      '</div>' +
                    '</div>' +
                    // Waveform
                    '<div class="lh-graph-box">' +
                      '<div class="lh-graph-hdr"><span class="lh-graph-lbl">OSCILLOSCOPE</span></div>' +
                      '<canvas id="lh-waveform" width="352" height="44"></canvas>' +
                    '</div>' +
                    // Meter
                    '<div class="lh-meter-box">' +
                      '<div class="lh-meter-scale"><span>-60</span><span>-48</span><span>-36</span><span>-24</span><span>-12</span><span>0</span></div>' +
                      '<div class="lh-meter-track"><div class="lh-meter-fill" id="lh-meter-fill"></div><div class="lh-meter-hold" id="lh-meter-hold"></div></div>' +
                      '<div class="lh-meter-foot"><div class="lh-led" id="lh-led"></div><span class="lh-meter-db" id="lh-meter-text">-&#x221e; dBFS</span></div>' +
                    '</div>' +
                    // Knobs
                    '<div class="lh-knob-section">' +
                      '<div class="lh-knob-section-title">GAIN CONTROL</div>' +
                      '<div class="lh-knobs-row">' +
                        '<div class="lh-knob-wrap" id="knob-wrap-masterGain">' +
                          '<div class="lh-knob-label">MASTER GAIN</div>' +
                          '<canvas class="lh-knob-canvas" id="knob-masterGain" width="72" height="72" data-param="masterGain" data-min="0" data-max="100" data-val="0"></canvas>' +
                          '<div class="lh-knob-val" id="knob-val-masterGain">+0 dB</div>' +
                        '</div>' +
                        '<div class="lh-knob-wrap" id="knob-wrap-inputBoost">' +
                          '<div class="lh-knob-label">PRE-AMP</div>' +
                          '<canvas class="lh-knob-canvas" id="knob-inputBoost" width="72" height="72" data-param="inputBoost" data-min="0" data-max="100" data-val="0"></canvas>' +
                          '<div class="lh-knob-val" id="knob-val-inputBoost">+0.0 dB</div>' +
                        '</div>' +
                        '<div class="lh-knob-wrap" id="knob-wrap-width">' +
                          '<div class="lh-knob-label">STEREO WIDTH</div>' +
                          '<canvas class="lh-knob-canvas" id="knob-width" width="72" height="72" data-param="width" data-min="0" data-max="100" data-val="0"></canvas>' +
                          '<div class="lh-knob-val" id="knob-val-width">0%</div>' +
                        '</div>' +
                      '</div>' +
                    '</div>' +
                  '</div>' +

                  // EQ TAB
                  '<div class="lh-tab-pane" data-tab="eq">' +
                    '<div class="lh-graph-box">' +
                      '<div class="lh-graph-hdr"><span class="lh-graph-lbl">EQ CURVE</span></div>' +
                      '<canvas id="lh-eq-curve" width="352" height="90"></canvas>' +
                      '<div class="lh-hz-scale"><span>BASS</span><span></span><span>MID</span><span></span><span>TREBLE</span></div>' +
                    '</div>' +
                    '<div class="lh-card">' +
                      this.makeSlider('eqBass',   'Bass',   0, 100, 50) +
                      this.makeSlider('eqMid',    'Mid',    0, 100, 50) +
                      this.makeSlider('eqTreble', 'Treble', 0, 100, 50) +
                    '</div>' +
                  '</div>' +

                  // VOICE TAB
                  '<div class="lh-tab-pane" data-tab="voice">' +
                    '<div class="lh-card">' +
                      '<div class="lh-sel-row">' +
                        '<span class="lh-sel-label">Voice Type</span>' +
                        '<div class="lh-sel-wrap"><select id="lh-voice-changer">' + voiceOpts + '</select></div>' +
                      '</div>' +
                      this.makeSlider('pitch',      'Pitch',      0,   100, 50) +
                      this.makeSlider('formant',    'Formant',    50,  200, 100) +
                      this.makeSlider('distortion', 'Distortion', 0,   100, 0) +
                      this.makeSlider('reverb',     'Reverb',     0,   100, 0) +
                    '</div>' +
                    '<div class="lh-card" style="margin-top:10px">' +
                      '<div class="lh-sel-row">' +
                        '<span class="lh-sel-label">Voice Profile</span>' +
                        '<div class="lh-sel-wrap"><select id="lh-voice-profile">' + profileOpts + '</select></div>' +
                      '</div>' +
                    '</div>' +
                  '</div>' +

                  // ADVANCED TAB
                  '<div class="lh-tab-pane" data-tab="advanced">' +
                    '<div class="lh-card">' +
                      '<div class="lh-tog-row"><span class="lh-tog-label">Noise Gate</span>' +
                        '<label class="lh-tog"><input type="checkbox" id="lh-gate-toggle" checked><span class="lh-tog-track"><span class="lh-tog-thumb"></span></span></label>' +
                      '</div>' +
                      this.makeSlider('gateThreshold', 'Threshold', -60, 0, -40) +
                      '<div class="lh-divider"></div>' +
                      '<div class="lh-tog-row"><span class="lh-tog-label">Noise Reduction</span>' +
                        '<label class="lh-tog"><input type="checkbox" id="lh-nr-toggle"><span class="lh-tog-track"><span class="lh-tog-thumb"></span></span></label>' +
                      '</div>' +
                      this.makeSlider('noiseReduction', 'Amount', 0, 100, 0) +
                      '<div class="lh-divider"></div>' +
                      '<div class="lh-tog-row"><span class="lh-tog-label">VAD</span>' +
                        '<label class="lh-tog"><input type="checkbox" id="lh-vad-toggle"><span class="lh-tog-track"><span class="lh-tog-thumb"></span></span></label>' +
                      '</div>' +
                      this.makeSlider('vadThreshold', 'VAD Threshold', -60, 0, -45) +
                      '<div class="lh-divider"></div>' +
                      '<div class="lh-tog-row"><span class="lh-tog-label">Audio Ducking</span>' +
                        '<label class="lh-tog"><input type="checkbox" id="lh-duck-toggle"><span class="lh-tog-track"><span class="lh-tog-thumb"></span></span></label>' +
                      '</div>' +
                      this.makeSlider('duckingReduction', 'Duck Amount', 0, 30, 10) +
                    '</div>' +
                    '<div class="lh-stats-card">' +
                      '<div class="lh-stats-title">VOICE STATS</div>' +
                      '<div class="lh-stats-grid">' +
                        '<div class="lh-stat-item"><span class="lh-stat-k">Speaking</span><span class="lh-stat-v" id="lh-s-speak">—</span></div>' +
                        '<div class="lh-stat-item"><span class="lh-stat-k">Avg Level</span><span class="lh-stat-v" id="lh-s-avg">—</span></div>' +
                        '<div class="lh-stat-item"><span class="lh-stat-k">Peak</span><span class="lh-stat-v" id="lh-s-peak">—</span></div>' +
                      '</div>' +
                      '<button class="lh-ghost-btn" id="lh-reset-stats">RESET STATS</button>' +
                    '</div>' +
                  '</div>' +

                  // PRESETS TAB
                  '<div class="lh-tab-pane" data-tab="presets">' +
                    '<div class="lh-presets-grid" id="lh-presets-grid">' + presetBtns + '</div>' +
                    '<div class="lh-preset-actions">' +
                      '<button class="lh-action-btn" id="lh-save-preset">SAVE</button>' +
                      '<button class="lh-action-btn lh-action-ghost" id="lh-reset-all">RESET ALL</button>' +
                    '</div>' +
                  '</div>' +
                '</div>' +

                '<div class="lh-footer"><span class="lh-footer-text">lite hook &middot; by nekwsite</span></div>';

            document.body.appendChild(this.panel);
            this.makeDraggable(this.panel.querySelector('#lh-header'));
        },

        makeSlider(id, label, min, max, def) {
            return '<div class="lh-sl-row">' +
                '<span class="lh-sl-label">' + label + '</span>' +
                '<div class="lh-sl-wrap">' +
                  '<input type="range" class="lh-slider" id="lh-' + id + '" min="' + min + '" max="' + max + '" value="' + def + '">' +
                '</div>' +
                '<span class="lh-sl-val" id="lh-val-' + id + '">' + def + '</span>' +
            '</div>';
        },

        injectCSS() {
            const style = document.createElement('style');
            style.id = 'lh-styles';
            style.textContent =
                ':root{--lhbg:#000;--lhsf:#0a0a0a;--lhsf2:#111;--lhbd:rgba(255,255,255,.08);--lhbda:rgba(255,255,255,.55);--lhtx:#fff;--lhd:rgba(255,255,255,.38);--lhm:rgba(255,255,255,.62);--lhgs:0 0 8px rgba(255,255,255,.4);--lhgm:0 0 16px rgba(255,255,255,.35),0 0 32px rgba(255,255,255,.15);--lhfn:\'Inter\',system-ui,sans-serif}' +
                // Button
                '#lh-btn{position:fixed;top:12px;left:12px;right:auto;touch-action:manipulation;pointer-events:auto;background:#000;border:1px solid rgba(255,255,255,.18);border-radius:100px;padding:8px 14px 8px 10px;display:flex;align-items:center;gap:8px;cursor:pointer;z-index:999999;font-family:var(--lhfn);transition:border-color .2s,box-shadow .2s;user-select:none}' +
                '#lh-btn:hover{border-color:rgba(255,255,255,.45);box-shadow:var(--lhgs)}' +
                '#lh-btn.active{border-color:rgba(255,255,255,.65);box-shadow:var(--lhgm)}' +
                '.lh-btn-dot{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.2);transition:background .3s,box-shadow .3s}' +
                '.lh-btn-dot.live{background:#fff;box-shadow:0 0 6px #fff,0 0 12px rgba(255,255,255,.5);animation:lhpulse 2s ease-in-out infinite}' +
                '@keyframes lhpulse{0%,100%{opacity:1}50%{opacity:.5}}' +
                '.lh-btn-label{font-size:12px;font-weight:600;letter-spacing:.08em;color:#fff}' +
                '.lh-btn-status{font-size:9px;font-weight:600;letter-spacing:.12em;color:var(--lhd);border:1px solid var(--lhbd);border-radius:4px;padding:2px 5px}' +
                '.lh-btn-status.live{color:#fff;border-color:rgba(255,255,255,.4);box-shadow:var(--lhgs)}' +
                // Quickbar
                '#lh-quickbar{position:fixed;bottom:18px;right:18px;top:auto;left:auto;background:#000;border:1px solid rgba(255,255,255,.1);border-radius:100px;padding:5px;display:flex;gap:4px;z-index:999998}' +
                '.lh-qb-btn{width:36px;height:36px;background:transparent;border:1px solid var(--lhbd);border-radius:50%;color:var(--lhd);cursor:pointer;font-size:7px;font-weight:700;letter-spacing:.05em;font-family:var(--lhfn);transition:all .15s}' +
                '.lh-qb-btn:hover{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.4);color:#fff;box-shadow:var(--lhgs)}' +
                '.lh-qb-btn.active{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.7);color:#fff;box-shadow:var(--lhgm)}' +
                // Panel
                '#lh-panel{position:fixed;top:70px;left:12px;right:auto;touch-action:pan-y;pointer-events:auto;width:min(380px,calc(100vw - 24px));background:#000;border:1px solid rgba(255,255,255,.1);border-radius:16px;color:#fff;font-family:var(--lhfn);font-size:12px;z-index:999999;box-shadow:0 32px 64px rgba(0,0,0,.85),inset 0 1px 0 rgba(255,255,255,.05);overflow:hidden;animation:lhpanelin .04s linear}' +
                '@keyframes lhpanelin{from{opacity:0;transform:translateY(-8px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}' +
                // Header
                '.lh-header{padding:13px 16px;display:flex;align-items:center;justify-content:space-between;cursor:move;border-bottom:1px solid var(--lhbd);background:linear-gradient(180deg,rgba(255,255,255,.03) 0%,transparent 100%)}' +
                '.lh-header-left{display:flex;align-items:center;gap:10px}' +
                '.lh-logo-mark{width:28px;height:28px;border-radius:8px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.03);flex-shrink:0;position:relative}' +
                '.lh-logo-mark::after{content:"";position:absolute;bottom:5px;left:5px;right:5px;height:2px;background:rgba(255,255,255,.7);border-radius:1px;box-shadow:0 0 5px rgba(255,255,255,.8)}' +
                '.lh-logo-mark::before{content:"";position:absolute;bottom:10px;left:8px;right:8px;height:2px;background:rgba(255,255,255,.3);border-radius:1px}' +
                '.lh-title-block{display:flex;flex-direction:column;gap:1px}' +
                '.lh-title{font-size:14px;font-weight:600;letter-spacing:.04em;color:#fff}' +
                '.lh-credit{font-size:9px;font-weight:400;letter-spacing:.1em;color:var(--lhd);text-transform:uppercase}' +
                '.lh-header-right{display:flex;align-items:center;gap:8px}' +
                '.lh-live-badge{font-size:9px;font-weight:700;letter-spacing:.15em;color:var(--lhd);border:1px solid var(--lhbd);border-radius:4px;padding:3px 7px;text-transform:uppercase;transition:all .3s}' +
                '.lh-live-badge.live{color:#fff;border-color:rgba(255,255,255,.5);box-shadow:var(--lhgs)}' +
                '.lh-close-btn{width:26px;height:26px;background:transparent;border:1px solid var(--lhbd);border-radius:6px;color:var(--lhd);cursor:pointer;font-size:13px;line-height:1;transition:all .15s;display:flex;align-items:center;justify-content:center}' +
                '.lh-close-btn:hover{border-color:rgba(255,255,255,.35);color:#fff}' +
                // Tabs
                '.lh-tabs{display:flex;padding:0 12px;border-bottom:1px solid var(--lhbd);overflow-x:auto;scrollbar-width:none}' +
                '.lh-tabs::-webkit-scrollbar{display:none}' +
                '.lh-tab{padding:10px 12px;background:transparent;border:none;border-bottom:2px solid transparent;color:var(--lhd);cursor:pointer;font-size:11px;font-weight:500;letter-spacing:.06em;text-transform:uppercase;font-family:var(--lhfn);white-space:nowrap;transition:color .15s,border-color .15s;margin-bottom:-1px}' +
                '.lh-tab:hover{color:rgba(255,255,255,.7)}' +
                '.lh-tab.active{color:#fff;border-bottom-color:#fff;text-shadow:0 0 8px rgba(255,255,255,.6)}' +
                // Body
                '.lh-body{padding:14px;max-height:530px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.08) transparent}' +
                '.lh-body::-webkit-scrollbar{width:3px}' +
                '.lh-body::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08);border-radius:3px}' +
                '.lh-tab-pane{display:none}.lh-tab-pane.active{display:block}' +
                // Graph boxes
                '.lh-graph-box{background:#000;border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:10px 12px;margin-bottom:9px;overflow:hidden}' +
                '.lh-graph-hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:7px}' +
                '.lh-graph-lbl{font-size:9px;font-weight:600;letter-spacing:.15em;color:var(--lhd);text-transform:uppercase}' +
                '.lh-peak-lbl{font-size:10px;font-weight:600;font-variant-numeric:tabular-nums;color:var(--lhm);letter-spacing:.04em}' +
                '#lh-spectrum,#lh-waveform,#lh-eq-curve{width:100%;display:block;border-radius:3px}' +
                '.lh-hz-scale{display:flex;justify-content:space-between;margin-top:4px}' +
                '.lh-hz-scale span{font-size:8px;color:rgba(255,255,255,.18);letter-spacing:.04em}' +
                // Meter
                '.lh-meter-box{margin-bottom:10px;background:#000;border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:10px 12px}' +
                '.lh-meter-scale{display:flex;justify-content:space-between;margin-bottom:4px}' +
                '.lh-meter-scale span{font-size:8px;color:rgba(255,255,255,.18);font-variant-numeric:tabular-nums}' +
                '.lh-meter-track{height:5px;background:rgba(255,255,255,.05);border-radius:3px;position:relative;margin-bottom:7px}' +
                '.lh-meter-fill{position:absolute;left:0;top:0;bottom:0;width:0%;background:linear-gradient(90deg,rgba(255,255,255,.35) 0%,rgba(255,255,255,.75) 70%,#fff 100%);border-radius:3px;transition:width .04s linear;box-shadow:0 0 6px rgba(255,255,255,.25)}' +
                '.lh-meter-hold{position:absolute;top:-1px;width:2px;height:7px;background:#fff;border-radius:1px;box-shadow:0 0 5px #fff;transition:left .08s linear}' +
                '.lh-meter-foot{display:flex;align-items:center;gap:8px}' +
                '.lh-led{width:7px;height:7px;border-radius:50%;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.12);transition:all .1s;flex-shrink:0}' +
                '.lh-led.active{background:#fff;box-shadow:0 0 7px #fff,0 0 14px rgba(255,255,255,.5);border-color:#fff}' +
                '.lh-meter-db{font-size:10px;font-weight:600;font-variant-numeric:tabular-nums;color:var(--lhm);letter-spacing:.04em}' +
                // ===== KNOB SECTION =====
                '.lh-knob-section{background:#000;border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:12px;margin-bottom:10px}' +
                '.lh-knob-section-title{font-size:9px;font-weight:600;letter-spacing:.15em;color:var(--lhd);text-transform:uppercase;margin-bottom:14px}' +
                '.lh-knobs-row{display:flex;justify-content:space-around;align-items:flex-start;gap:10px}' +
                '.lh-knob-wrap{display:flex;flex-direction:column;align-items:center;gap:7px;cursor:ns-resize;user-select:none;-webkit-user-select:none}' +
                '.lh-knob-label{font-size:8px;font-weight:600;letter-spacing:.12em;color:var(--lhd);text-transform:uppercase;text-align:center}' +
                '.lh-knob-canvas{display:block;cursor:ns-resize;touch-action:none}' +
                '.lh-knob-val{font-size:10px;font-weight:600;font-variant-numeric:tabular-nums;color:var(--lhm);letter-spacing:.04em;text-align:center;min-width:60px}' +
                // Card
                '.lh-card{background:var(--lhsf);border:1px solid var(--lhbd);border-radius:10px;padding:12px;margin-bottom:10px}' +
                '.lh-divider{height:1px;background:var(--lhbd);margin:10px 0}' +
                // Sliders
                '.lh-sl-row{display:flex;align-items:center;gap:10px;margin-bottom:10px}' +
                '.lh-sl-row:last-child{margin-bottom:0}' +
                '.lh-sl-label{width:92px;flex-shrink:0;font-size:11px;color:var(--lhm)}' +
                '.lh-sl-wrap{flex:1;position:relative}' +
                '.lh-slider{-webkit-appearance:none;appearance:none;width:100%;height:3px;background:rgba(255,255,255,.1);border-radius:2px;outline:none;cursor:pointer}' +
                '.lh-slider::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;border-radius:50%;background:#fff;border:none;box-shadow:0 0 7px rgba(255,255,255,.5),0 0 14px rgba(255,255,255,.2);cursor:pointer;transition:box-shadow .15s}' +
                '.lh-slider:active::-webkit-slider-thumb{box-shadow:0 0 12px rgba(255,255,255,.8),0 0 22px rgba(255,255,255,.4)}' +
                '.lh-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;background:#fff;border:none;box-shadow:0 0 7px rgba(255,255,255,.5)}' +
                '.lh-sl-val{width:56px;flex-shrink:0;text-align:right;font-size:10px;font-weight:600;font-variant-numeric:tabular-nums;color:rgba(255,255,255,.5);letter-spacing:.04em}' +
                // Selects
                '.lh-sel-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}' +
                '.lh-sel-label{font-size:11px;color:var(--lhm)}' +
                '.lh-sel-wrap{position:relative}' +
                '.lh-sel-wrap select{appearance:none;-webkit-appearance:none;background:var(--lhsf2);border:1px solid rgba(255,255,255,.12);border-radius:6px;color:#fff;font-size:11px;font-weight:500;font-family:var(--lhfn);padding:5px 22px 5px 9px;cursor:pointer;outline:none;transition:border-color .15s}' +
                '.lh-sel-wrap select:focus{border-color:rgba(255,255,255,.35);box-shadow:var(--lhgs)}' +
                '.lh-sel-wrap::after{content:"";position:absolute;right:8px;top:50%;transform:translateY(-60%) rotate(45deg);width:5px;height:5px;border-right:1.5px solid rgba(255,255,255,.4);border-bottom:1.5px solid rgba(255,255,255,.4);pointer-events:none}' +
                // Toggles
                '.lh-tog-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}' +
                '.lh-tog-label{font-size:11px;color:var(--lhm)}' +
                '.lh-tog{position:relative;display:inline-block;cursor:pointer}' +
                '.lh-tog input{display:none}' +
                '.lh-tog-track{display:block;width:36px;height:20px;background:rgba(255,255,255,.07);border-radius:10px;border:1px solid rgba(255,255,255,.1);transition:all .2s;position:relative}' +
                '.lh-tog-thumb{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:rgba(255,255,255,.28);transition:all .2s}' +
                '.lh-tog input:checked + .lh-tog-track{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.4);box-shadow:var(--lhgs)}' +
                '.lh-tog input:checked + .lh-tog-track .lh-tog-thumb{left:18px;background:#fff;box-shadow:0 0 7px rgba(255,255,255,.6)}' +
                // Stats
                '.lh-stats-card{background:var(--lhsf);border:1px solid var(--lhbd);border-radius:10px;padding:12px;margin-top:10px}' +
                '.lh-stats-title{font-size:9px;font-weight:600;letter-spacing:.15em;color:var(--lhd);text-transform:uppercase;margin-bottom:10px}' +
                '.lh-stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}' +
                '.lh-stat-item{display:flex;flex-direction:column;gap:3px}' +
                '.lh-stat-k{font-size:9px;color:var(--lhd);text-transform:uppercase;letter-spacing:.08em}' +
                '.lh-stat-v{font-size:11px;font-weight:600;color:#fff;font-variant-numeric:tabular-nums}' +
                '.lh-ghost-btn{width:100%;padding:7px;background:transparent;border:1px solid var(--lhbd);border-radius:6px;color:var(--lhd);font-size:9px;font-weight:600;font-family:var(--lhfn);letter-spacing:.12em;text-transform:uppercase;cursor:pointer;transition:all .15s}' +
                '.lh-ghost-btn:hover{border-color:rgba(255,255,255,.3);color:#fff}' +
                // Presets
                '.lh-presets-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:12px}' +
                '.lh-preset-btn{padding:12px;background:var(--lhsf);border:1px solid var(--lhbd);border-radius:10px;color:var(--lhm);font-size:11px;font-weight:500;font-family:var(--lhfn);cursor:pointer;transition:all .15s;text-align:center;letter-spacing:.04em}' +
                '.lh-preset-btn:hover{border-color:rgba(255,255,255,.32);color:#fff;background:rgba(255,255,255,.04)}' +
                '.lh-preset-btn.active{border-color:rgba(255,255,255,.6);color:#fff;background:rgba(255,255,255,.05);box-shadow:var(--lhgm);text-shadow:0 0 7px rgba(255,255,255,.5)}' +
                '.lh-preset-actions{display:flex;gap:8px}' +
                '.lh-action-btn{flex:1;padding:10px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.18);border-radius:8px;color:#fff;font-size:10px;font-weight:700;font-family:var(--lhfn);letter-spacing:.12em;text-transform:uppercase;cursor:pointer;transition:all .15s}' +
                '.lh-action-btn:hover{background:rgba(255,255,255,.11);border-color:rgba(255,255,255,.45);box-shadow:var(--lhgs)}' +
                '.lh-action-ghost{background:transparent;border-color:var(--lhbd);color:var(--lhd)}' +
                '.lh-action-ghost:hover{background:rgba(255,255,255,.04);border-color:rgba(255,255,255,.22);color:#fff}' +
                // Footer
                '.lh-footer{padding:8px 16px;border-top:1px solid var(--lhbd);text-align:center;background:rgba(255,255,255,.01)}' +
                '.lh-footer-text{font-size:9px;color:rgba(255,255,255,.16);letter-spacing:.1em}' +
                // Toast
                '.lh-toast{position:fixed;bottom:80px;left:50%;transform:translateX(-50%);background:#111;border:1px solid rgba(255,255,255,.2);border-radius:100px;padding:8px 18px;color:#fff;font-family:var(--lhfn);font-size:11px;font-weight:500;letter-spacing:.06em;z-index:1000001;box-shadow:var(--lhgs);animation:lhtoast 2.2s ease forwards;white-space:nowrap}' +
                '@keyframes lhtoast{0%{opacity:0;transform:translateX(-50%) translateY(8px)}15%{opacity:1;transform:translateX(-50%) translateY(0)}75%{opacity:1}100%{opacity:0;transform:translateX(-50%) translateY(-4px)}}';

            // FIX: use documentElement as fallback if head not ready
            (document.head || document.documentElement).appendChild(style);
        },

        // ===== KNOB DRAWING =====
        drawKnob(canvas, normalizedValue) {
            const W = canvas.width, H = canvas.height;
            const ctx = canvas.getContext('2d');
            const cx = W / 2, cy = H / 2 + 2;
            const radius = Math.min(W, H) * 0.38;

            // Angle range: -135deg to +135deg (270 total)
            const startAngle = Math.PI * 0.75;  // 135deg
            const endAngle   = Math.PI * 2.25;  // 405deg (= 45deg)
            const angle = startAngle + normalizedValue * (endAngle - startAngle);

            ctx.clearRect(0, 0, W, H);

            // --- Outer ring track (dark arc) ---
            ctx.beginPath();
            ctx.arc(cx, cy, radius + 5, startAngle, endAngle);
            ctx.strokeStyle = 'rgba(255,255,255,0.06)';
            ctx.lineWidth = 3;
            ctx.lineCap = 'round';
            ctx.stroke();

            // --- Active arc (value filled) ---
            if (normalizedValue > 0.001) {
                ctx.beginPath();
                ctx.arc(cx, cy, radius + 5, startAngle, angle);
                ctx.strokeStyle = 'rgba(255,255,255,0.55)';
                ctx.lineWidth = 3;
                ctx.lineCap = 'round';
                ctx.shadowColor = 'rgba(255,255,255,0.4)';
                ctx.shadowBlur = 6;
                ctx.stroke();
                ctx.shadowBlur = 0;
            }

            // --- Knob body: dark oval with perspective look ---
            // Outer shadow ring
            const bodyGrad = ctx.createRadialGradient(cx, cy - radius * 0.2, radius * 0.1, cx, cy, radius);
            bodyGrad.addColorStop(0, '#222');
            bodyGrad.addColorStop(0.6, '#111');
            bodyGrad.addColorStop(1, '#050505');
            ctx.beginPath();
            ctx.ellipse(cx, cy, radius, radius * 0.88, 0, 0, Math.PI * 2);
            ctx.fillStyle = bodyGrad;
            ctx.fill();

            // Rim highlight (top edge)
            ctx.beginPath();
            ctx.ellipse(cx, cy, radius, radius * 0.88, 0, 0, Math.PI * 2);
            ctx.strokeStyle = 'rgba(255,255,255,0.12)';
            ctx.lineWidth = 1;
            ctx.stroke();

            // Top specular glint
            const glintGrad = ctx.createLinearGradient(cx - radius * 0.5, cy - radius * 0.85, cx + radius * 0.5, cy - radius * 0.4);
            glintGrad.addColorStop(0, 'rgba(255,255,255,0.18)');
            glintGrad.addColorStop(1, 'rgba(255,255,255,0)');
            ctx.beginPath();
            ctx.ellipse(cx, cy - radius * 0.55, radius * 0.55, radius * 0.15, 0, 0, Math.PI * 2);
            ctx.fillStyle = glintGrad;
            ctx.fill();

            // --- Indicator line (white, from center to edge) ---
            const lineInner = radius * 0.25;
            const lineOuter = radius * 0.82;
            const ix = cx + Math.cos(angle) * lineInner;
            const iy = cy + Math.sin(angle) * lineInner;
            const ox = cx + Math.cos(angle) * lineOuter;
            const oy = cy + Math.sin(angle) * lineOuter;

            ctx.beginPath();
            ctx.moveTo(ix, iy);
            ctx.lineTo(ox, oy);
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.lineCap = 'round';
            ctx.shadowColor = 'rgba(255,255,255,0.9)';
            ctx.shadowBlur = 8;
            ctx.stroke();
            ctx.shadowBlur = 0;

            // Tip dot
            ctx.beginPath();
            ctx.arc(ox, oy, 2.5, 0, Math.PI * 2);
            ctx.fillStyle = '#fff';
            ctx.shadowColor = '#fff';
            ctx.shadowBlur = 8;
            ctx.fill();
            ctx.shadowBlur = 0;
        },

        initKnobCanvases() {
            KNOBS.forEach((k) => {
                const canvas = document.getElementById(k.id);
                if (!canvas) return;
                const norm = (PARAMS[k.param] - k.min) / (k.max - k.min);
                this.drawKnob(canvas, norm);
            });
        },

        updateKnobDisplay(paramId, rawVal) {
            const k = KNOBS.find((x) => x.param === paramId);
            if (!k) return;
            const canvas = document.getElementById(k.id);
            if (!canvas) return;
            const norm = (rawVal - k.min) / (k.max - k.min);
            this.drawKnob(canvas, norm);
            const valEl = document.getElementById('knob-val-' + paramId);
            if (valEl) valEl.textContent = k.formatFn(rawVal);
        },

        bindKnobs() {
            const self = this;
            KNOBS.forEach((k) => {
                const canvas = document.getElementById(k.id);
                if (!canvas) return;

                let dragging = false, startY = 0, startVal = 0;

                const onStart = function(e) {
                    dragging = true;
                    startY = (e.touches ? e.touches[0].clientY : e.clientY);
                    startVal = PARAMS[k.param];
                    e.preventDefault();
                };
                const onMove = function(e) {
                    if (!dragging) return;
                    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
                    const dy = startY - clientY; // up = positive
                    const range = k.max - k.min;
                    // 150px = full range
                    const newVal = Math.max(k.min, Math.min(k.max, startVal + (dy / 150) * range));
                    PARAMS[k.param] = newVal;
                    self.updateKnobDisplay(k.param, newVal);
                    Core.update();
                    e.preventDefault();
                };
                const onEnd = function() { dragging = false; };

                canvas.addEventListener('mousedown', onStart);
                canvas.addEventListener('touchstart', onStart, { passive: false });
                document.addEventListener('mousemove', onMove);
                document.addEventListener('touchmove', onMove, { passive: false });
                document.addEventListener('mouseup', onEnd);
                document.addEventListener('touchend', onEnd);
            });
        },

        bindEvents() {
            const self = this;
            // Toggle panel
            const openFromLauncher = function(e) {
                e.preventDefault();
                e.stopPropagation();
                self.togglePanel(!uiVisible);
            };
            this.button.addEventListener('click', openFromLauncher);
            this.button.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') openFromLauncher(e);
            });

            // Close
            document.addEventListener('click', function(e) {
                if (e.target.id === 'lh-close' || e.target.closest('#lh-close')) { e.preventDefault(); e.stopPropagation(); self.togglePanel(false); }
            });

            // Tabs
            document.addEventListener('click', function(e) {
                const tab = e.target.closest('.lh-tab');
                if (!tab || !tab.dataset.tab) return;
                const name = tab.dataset.tab;
                document.querySelectorAll('.lh-tab').forEach(function(t) { t.classList.toggle('active', t.dataset.tab === name); });
                document.querySelectorAll('.lh-tab-pane').forEach(function(p) { p.classList.toggle('active', p.dataset.tab === name); });
            });

            // Sliders
            document.addEventListener('input', function(e) {
                if (!e.target.classList.contains('lh-slider')) return;
                const rawId = e.target.id.replace('lh-', '');
                const val = parseFloat(e.target.value);
                self.applySlider(rawId, val);
            });

            // Selects
            document.addEventListener('change', function(e) {
                if (e.target.id === 'lh-voice-changer') { PARAMS.voiceChanger = e.target.value; Core.update(); }
                if (e.target.id === 'lh-voice-profile') {
                    PARAMS.voiceProfile = e.target.value;
                    const prof = VOICE_PROFILES[e.target.value];
                    if (prof) { Object.assign(PARAMS, prof); self.syncAllSliders(); Core.update(); }
                }
            });

            // Toggles
            document.addEventListener('change', function(e) {
                if (e.target.id === 'lh-gate-toggle') Core.update();
                if (e.target.id === 'lh-nr-toggle') Core.update();
                if (e.target.id === 'lh-vad-toggle') PARAMS.vadEnabled = e.target.checked;
                if (e.target.id === 'lh-duck-toggle') { PARAMS.duckingEnabled = e.target.checked; Core.update(); }
            });

            // Presets
            document.addEventListener('click', function(e) {
                const btn = e.target.closest('.lh-preset-btn');
                if (!btn || !btn.dataset.preset) return;
                const name = btn.dataset.preset;
                if (PRESETS[name]) {
                    const defs = { masterGain:0,inputBoost:0,width:0,pitch:50,reverb:0,eqBass:50,eqMid:50,eqTreble:50,gateThreshold:-40,formant:100,distortion:0,noiseReduction:0,vadThreshold:-45,duckingReduction:10 };
                    Object.assign(PARAMS, defs, PRESETS[name]);
                    self.syncAllSliders();
                    Core.update();
                    document.querySelectorAll('.lh-preset-btn').forEach(function(b) { b.classList.toggle('active', b === btn); });
                    self.showToast(name);
                }
            });

            // Buttons
            document.addEventListener('click', function(e) {
                if (e.target.id === 'lh-save-preset') self.quickSavePreset();
                if (e.target.id === 'lh-reset-all') self.resetAll();
                if (e.target.id === 'lh-reset-stats') Stats.reset();
            });

            // Quick bar
            this.quickBar.addEventListener('click', function(e) {
                const btn = e.target.closest('.lh-qb-btn');
                if (!btn) return;
                const action = btn.dataset.action;
                if (action === 'mute') {
                    PARAMS.masterGain = (PARAMS.masterGain === -60) ? 0 : -60;
                    self.updateKnobDisplay('masterGain', PARAMS.masterGain < 0 ? 0 : PARAMS.masterGain);
                    btn.classList.toggle('active', PARAMS.masterGain === -60);
                    Core.update();
                } else if (action === 'voice') {
                    const voices = Object.keys(VOICE_PRESETS);
                    const cur = voices.indexOf(PARAMS.voiceChanger);
                    PARAMS.voiceChanger = voices[(cur + 1) % voices.length];
                    const sel = document.getElementById('lh-voice-changer');
                    if (sel) sel.value = PARAMS.voiceChanger;
                    Core.update();
                    self.showToast(PARAMS.voiceChanger === 'none' ? 'Voice: Off' : 'Voice: ' + PARAMS.voiceChanger);
                } else if (action === 'preset') {
                    self.quickSavePreset();
                } else if (action === 'stats') {
                    const s = Stats.getStats();
                    self.showToast('Peak: ' + s.peakVolume);
                }
            });
        },

        applySlider(id, val) {
            const fmts = {
                masterGain:       function(v) { return (v>=0?'+':'')+v+' dB'; },
                inputBoost:       function(v) { var d=(v*0.2).toFixed(1); return (parseFloat(d)>=0?'+':'')+d+' dB'; },
                width:            function(v) { return v+'%'; },
                pitch:            function(v) { var s=Math.round((v-50)/5); return (s>0?'+':'')+s+' st'; },
                formant:          function(v) { return (v/100).toFixed(2)+'x'; },
                distortion:       function(v) { return v+'%'; },
                reverb:           function(v) { return v+'%'; },
                eqBass:           function(v) { var d=Math.round((v-50)*0.24); return (d>0?'+':'')+d+' dB'; },
                eqMid:            function(v) { var d=Math.round((v-50)*0.24); return (d>0?'+':'')+d+' dB'; },
                eqTreble:         function(v) { var d=Math.round((v-50)*0.24); return (d>0?'+':'')+d+' dB'; },
                gateThreshold:    function(v) { return v+' dB'; },
                noiseReduction:   function(v) { return v+'%'; },
                vadThreshold:     function(v) { return v+' dB'; },
                duckingReduction: function(v) { return v+' dB'; }
            };
            if (PARAMS.hasOwnProperty(id)) PARAMS[id] = val;
            const valEl = document.getElementById('lh-val-' + id);
            if (valEl && fmts[id]) valEl.textContent = fmts[id](val);
            Core.update();
        },

        syncAllSliders() {
            const map = [
                ['masterGain',       PARAMS.masterGain],
                ['inputBoost',       PARAMS.inputBoost],
                ['width',            PARAMS.width],
                ['pitch',            PARAMS.pitch],
                ['eqBass',           PARAMS.eqBass],
                ['eqMid',            PARAMS.eqMid],
                ['eqTreble',         PARAMS.eqTreble],
                ['gateThreshold',    PARAMS.gateThreshold],
                ['formant',          PARAMS.formant * 100],
                ['distortion',       PARAMS.distortion],
                ['reverb',           PARAMS.reverb],
                ['noiseReduction',   PARAMS.noiseReduction],
                ['vadThreshold',     PARAMS.vadThreshold],
                ['duckingReduction', PARAMS.duckingReduction]
            ];
            const self = this;
            map.forEach(function(item) {
                const el = document.getElementById('lh-' + item[0]);
                if (el) { el.value = item[1]; self.applySlider(item[0], item[1]); }
            });
            // Sync knobs
            KNOBS.forEach(function(k) { self.updateKnobDisplay(k.param, PARAMS[k.param]); });
        },

        updateMeter(peak) {
            const db = 20 * Math.log10(Math.max(peak, 1e-6));
            const norm = Math.max(0, Math.min(1, (db + 60) / 60));
            currentMeterPeak = norm;
            if (norm > peakHoldVal) { peakHoldVal = norm; peakHoldTimer = 60; }
            const fill = document.getElementById('lh-meter-fill');
            const hold = document.getElementById('lh-meter-hold');
            const text = document.getElementById('lh-meter-text');
            const led  = document.getElementById('lh-led');
            const plbl = document.getElementById('lh-peak-label');
            if (fill) fill.style.width = (norm * 100) + '%';
            if (hold) hold.style.left  = (peakHoldVal * 100) + '%';
            if (text) text.textContent = (db > -60 ? db.toFixed(1) : '-\u221e') + ' dBFS';
            if (led)  led.classList.toggle('active', db > -40);
            if (plbl) plbl.textContent = (db > -60 ? db.toFixed(1) : '\u2014') + ' dBFS';
            const dot = document.getElementById('lh-dot');
            if (dot) dot.classList.toggle('live', db > -50);
            Stats.update(db);
        },

        // ===== ADVANCED SPECTRUM =====
        drawSpectrum() {
            const canvas = document.getElementById('lh-spectrum');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            const W = canvas.width, H = canvas.height;
            const data = Core.getSpectrum();
            ctx.clearRect(0, 0, W, H);

            // Grid
            ctx.strokeStyle = 'rgba(255,255,255,0.04)';
            ctx.lineWidth = 1;
            for (let i = 1; i < 4; i++) {
                const y = (i / 4) * H;
                ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
            }
            if (!data.length) return;

            const numBars = 64;
            const step = Math.floor(data.length / numBars);
            const bw = W / numBars;

            for (let i = 0; i < numBars; i++) {
                let sum = 0;
                for (let j = 0; j < step; j++) sum += data[i * step + j];
                const val = sum / step / 255;
                const h = val * H;

                if (val > peakHistory[i]) peakHistory[i] = val;
                else peakHistory[i] *= 0.93;

                // Glow layer
                ctx.fillStyle = 'rgba(255,255,255,' + (val * 0.07) + ')';
                ctx.fillRect(i * bw + 0.5, H - h - 3, bw - 1, h + 3);

                // Main bar
                if (h > 0.5) {
                    const grad = ctx.createLinearGradient(0, H - h, 0, H);
                    grad.addColorStop(0, 'rgba(255,255,255,' + (0.3 + val * 0.7) + ')');
                    grad.addColorStop(1, 'rgba(255,255,255,' + (0.1 + val * 0.2) + ')');
                    ctx.fillStyle = grad;
                    ctx.fillRect(i * bw + 1, H - h, bw - 2, h);

                    // Top cap
                    ctx.fillStyle = 'rgba(255,255,255,' + (0.7 + val * 0.3) + ')';
                    ctx.fillRect(i * bw + 1, H - h - 1, bw - 2, 2);
                }
            }

            // Peak line
            ctx.beginPath();
            ctx.strokeStyle = 'rgba(255,255,255,0.45)';
            ctx.lineWidth = 1;
            ctx.shadowColor = 'rgba(255,255,255,0.5)';
            ctx.shadowBlur = 4;
            for (let i = 0; i < numBars; i++) {
                const x = i * bw + bw / 2;
                const y = H - peakHistory[i] * H;
                if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.stroke();
            ctx.shadowBlur = 0;
        },

        // ===== ADVANCED WAVEFORM =====
        drawWaveform() {
            const canvas = document.getElementById('lh-waveform');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            const W = canvas.width, H = canvas.height;
            const data = Core.getWaveform();
            ctx.clearRect(0, 0, W, H);

            // Center line
            ctx.strokeStyle = 'rgba(255,255,255,0.05)';
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2); ctx.stroke();

            if (!data.length) return;
            const step = Math.max(1, Math.floor(data.length / W));

            // Glow pass
            ctx.save();
            ctx.shadowColor = 'rgba(255,255,255,0.35)';
            ctx.shadowBlur = 5;
            ctx.beginPath();
            ctx.strokeStyle = 'rgba(255,255,255,0.2)';
            ctx.lineWidth = 3;
            for (let x = 0; x < W; x++) {
                const val = (data[x * step] - 128) / 128;
                const y = H / 2 + val * (H / 2 - 3);
                if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.stroke();
            ctx.restore();

            // Sharp line
            ctx.beginPath();
            ctx.strokeStyle = 'rgba(255,255,255,0.85)';
            ctx.lineWidth = 1.5;
            for (let x = 0; x < W; x++) {
                const val = (data[x * step] - 128) / 128;
                const y = H / 2 + val * (H / 2 - 3);
                if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.stroke();
        },

        // ===== ADVANCED EQ CURVE =====
        drawEQCurve() {
            const canvas = document.getElementById('lh-eq-curve');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            const W = canvas.width, H = canvas.height;
            ctx.clearRect(0, 0, W, H);

            // Grid
            ctx.strokeStyle = 'rgba(255,255,255,0.04)';
            ctx.lineWidth = 1;
            for (let i = 1; i < 4; i++) {
                const y = (i / 4) * H;
                ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
            }
            [0.33, 0.66].forEach(function(x) {
                ctx.beginPath(); ctx.moveTo(x * W, 0); ctx.lineTo(x * W, H); ctx.stroke();
            });

            const bass = PARAMS.eqBass / 50;
            const mid  = PARAMS.eqMid  / 50;
            const treble = PARAMS.eqTreble / 50;

            function getGain(t) {
                if (t < 0.33) return bass * (1 - t / 0.33) + 1 * (t / 0.33);
                if (t < 0.66) return 1 * (1 - (t - 0.33) / 0.33) + mid * ((t - 0.33) / 0.33);
                return mid * (1 - (t - 0.66) / 0.34) + treble * ((t - 0.66) / 0.34);
            }

            // Fill
            ctx.beginPath();
            for (let x = 0; x <= W; x++) {
                const gain = getGain(x / W);
                const y = H * 0.5 - (gain - 1) * H * 0.35;
                if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
            const fillG = ctx.createLinearGradient(0, 0, 0, H);
            fillG.addColorStop(0, 'rgba(255,255,255,0.07)');
            fillG.addColorStop(1, 'rgba(255,255,255,0)');
            ctx.fillStyle = fillG; ctx.fill();

            // Glow line
            ctx.save();
            ctx.shadowColor = 'rgba(255,255,255,0.45)';
            ctx.shadowBlur = 7;
            ctx.beginPath();
            for (let x = 0; x <= W; x++) {
                const y = H * 0.5 - (getGain(x / W) - 1) * H * 0.35;
                if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.strokeStyle = 'rgba(255,255,255,0.55)';
            ctx.lineWidth = 2;
            ctx.stroke();
            ctx.restore();

            // Sharp line
            ctx.beginPath();
            for (let x = 0; x <= W; x++) {
                const y = H * 0.5 - (getGain(x / W) - 1) * H * 0.35;
                if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
            }
            ctx.strokeStyle = 'rgba(255,255,255,0.9)';
            ctx.lineWidth = 1.5;
            ctx.stroke();

            // Band dots
            [[0.16, bass], [0.5, mid], [0.83, treble]].forEach(function(item) {
                const x = item[0] * W;
                const y = H * 0.5 - (item[1] - 1) * H * 0.35;
                ctx.beginPath();
                ctx.arc(x, y, 4, 0, Math.PI * 2);
                ctx.fillStyle = '#fff';
                ctx.shadowColor = 'rgba(255,255,255,0.8)';
                ctx.shadowBlur = 7;
                ctx.fill();
                ctx.shadowBlur = 0;
            });
        },

        updateStats() {
            const s = Stats.getStats();
            const sp = document.getElementById('lh-s-speak');
            const av = document.getElementById('lh-s-avg');
            const pk = document.getElementById('lh-s-peak');
            if (sp) sp.textContent = s.speakingTime;
            if (av) av.textContent = s.avgVolume;
            if (pk) pk.textContent = s.peakVolume;
            if (peakHoldTimer > 0) peakHoldTimer--;
            else if (peakHoldVal > 0) peakHoldVal = Math.max(0, peakHoldVal - 0.002);
        },

        showToast(msg) {
            const old = document.querySelector('.lh-toast');
            if (old) old.remove();
            const t = document.createElement('div');
            t.className = 'lh-toast';
            t.textContent = msg;
            document.body.appendChild(t);
            setTimeout(function() { t.remove(); }, 2200);
        },

        quickSavePreset() {
            const name = prompt('Preset name:');
            if (!name) return;
            const preset = {};
            Object.keys(PARAMS).forEach(function(k) { if (typeof PARAMS[k] === 'number') preset[k] = PARAMS[k]; });
            try { localStorage.setItem('lh_preset_' + name, JSON.stringify(preset)); } catch(e) {}
            PRESETS[name] = preset;
            const grid = document.getElementById('lh-presets-grid');
            if (grid && !document.querySelector('[data-preset="' + name + '"]')) {
                const btn = document.createElement('button');
                btn.className = 'lh-preset-btn';
                btn.dataset.preset = name;
                btn.textContent = name;
                grid.appendChild(btn);
            }
            this.showToast('Saved: ' + name);
        },

        resetAll() {
            Object.assign(PARAMS, {
                masterGain:0,inputBoost:0,width:0,pitch:50,reverb:0,
                eqBass:50,eqMid:50,eqTreble:50,gateThreshold:-40,
                formant:100,distortion:0,noiseReduction:0,vadThreshold:-45,duckingReduction:10
            });
            this.syncAllSliders();
            Core.update();
            document.querySelectorAll('.lh-preset-btn').forEach(function(b) { b.classList.remove('active'); });
            this.showToast('Reset complete');
        },

        startAnimationLoop() {
            const self = this;
            const loop = function(timestamp) {
                if (uiVisible && timestamp - lastFrameTime > FRAME_TIME) {
                    self.drawSpectrum();
                    self.drawWaveform();
                    self.drawEQCurve();
                    self.updateStats();
                    lastFrameTime = timestamp;
                }
                animationFrame = requestAnimationFrame(loop);
            };
            animationFrame = requestAnimationFrame(loop);
        },

        togglePanel(forceState) {
            if (!this.panel || !this.button) return;
            // Explicit state avoids close/touch events accidentally toggling twice.
            uiVisible = (typeof forceState === 'boolean') ? forceState : !uiVisible;
            this.panel.style.display = uiVisible ? 'block' : 'none';
            this.panel.setAttribute('aria-hidden', uiVisible ? 'false' : 'true');
            this.button.classList.toggle('active', uiVisible);
            this.button.setAttribute('aria-expanded', uiVisible ? 'true' : 'false');
            if (uiVisible) {
                const r = this.button.getBoundingClientRect();
                const panelWidth = Math.min(380, window.innerWidth - 16);
                const panelHeight = Math.min(this.panel.scrollHeight || 580, window.innerHeight - 16);
                this.panel.style.top = Math.max(8, Math.min(r.bottom + 10, window.innerHeight - panelHeight - 8)) + 'px';
                this.panel.style.left = Math.max(8, Math.min(r.left, window.innerWidth - panelWidth - 8)) + 'px';
                this.panel.style.right = 'auto';
                this.panel.style.maxHeight = 'calc(100vh - 16px)';
                this.panel.style.overflowY = 'auto';
                this.syncAllSliders();
                this.initKnobCanvases();
            }
        },

        setStatus(text) {
            const s = document.getElementById('lh-status');
            const l = document.getElementById('lh-live');
            const d = document.getElementById('lh-dot');
            const live = text === 'LIVE';
            if (s) { s.textContent = text; s.classList.toggle('live', live); }
            if (l) { l.textContent = text; l.classList.toggle('live', live); }
            if (d) d.classList.toggle('live', live);
        },

        makeDraggable(handle) {
            const self = this;
            let dragging = false, startX = 0, startY = 0, origX = 0, origY = 0;
            const getPanel = function() { return handle.id === 'lh-header' ? self.panel : handle; };

            const onStart = function(e) {
                if (e.target.closest('button,input,select')) return;
                dragging = true;
                const touch = e.touches ? e.touches[0] : e;
                startX = touch.clientX; startY = touch.clientY;
                const rect = getPanel().getBoundingClientRect();
                origX = rect.left; origY = rect.top;
                e.preventDefault();
            };
            const onMove = function(e) {
                if (!dragging) return;
                const touch = e.touches ? e.touches[0] : e;
                getPanel().style.left  = (origX + touch.clientX - startX) + 'px';
                getPanel().style.top   = (origY + touch.clientY - startY) + 'px';
                getPanel().style.right = 'auto';
            };
            const onEnd = function() { dragging = false; };

            handle.addEventListener('mousedown', onStart);
            handle.addEventListener('touchstart', onStart, { passive: false });
            document.addEventListener('mousemove', onMove);
            document.addEventListener('touchmove', onMove, { passive: false });
            document.addEventListener('mouseup', onEnd);
            document.addEventListener('touchend', onEnd);
        }
    };

    // ===== INIT =====
    function initWhenBodyReady() {
        if (!document.body) {
            document.addEventListener('DOMContentLoaded', initWhenBodyReady, { once: true });
            return;
        }
        try { UI.init(); }
        catch (err) {
            // Allow a later retry if the host page was still rebuilding its DOM.
            window.__FIXA_MIC_INIT_STARTED__ = false;
            console.warn('[FIXA MIC] UI initialization failed; retrying after DOM ready.', err);
        }
    }
    if (document.readyState === 'loading' || !document.body) {
        document.addEventListener('DOMContentLoaded', initWhenBodyReady, { once: true });
    } else {
        initWhenBodyReady();
    }
})();
