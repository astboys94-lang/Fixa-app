package com.fixa.micpanel

import kotlin.math.*

/** Same controls as the FIXA extension's mic panel. */
class FxParams {
    var gainDb = 0          // -12..24
    var pitch = 50          // 0..100 (50 = normal)
    var bass = 50
    var mid = 50
    var treble = 50
    var reverb = 0
    var gateDb = -80        // -80 = gate off
    var distortion = 0

    fun reset() {
        gainDb = 0; pitch = 50; bass = 50; mid = 50; treble = 50
        reverb = 0; gateDb = -80; distortion = 0
    }
}

object Presets {
    // voice changer: pitch, distortion, reverb (values from the extension)
    val voices: LinkedHashMap<String, IntArray> = linkedMapOf(
        "none" to intArrayOf(50, 0, 0),
        "robot" to intArrayOf(30, 30, 10),
        "chipmunk" to intArrayOf(75, 0, 5),
        "alien" to intArrayOf(40, 20, 40),
        "demon" to intArrayOf(25, 50, 30),
        "giant" to intArrayOf(30, 10, 50),
        "echo" to intArrayOf(50, 0, 70),
        "helium" to intArrayOf(70, 0, 10)
    )

    // gain, bass, mid, treble, gate, reverb
    val eq: LinkedHashMap<String, IntArray> = linkedMapOf(
        "Default" to intArrayOf(0, 50, 50, 50, -80, 0),
        "Bass Boost" to intArrayOf(5, 80, 50, 40, -80, 0),
        "Voice Clarity" to intArrayOf(0, 40, 65, 70, -50, 0),
        "Radio" to intArrayOf(0, 30, 70, 30, -80, 30),
        "Podcast" to intArrayOf(0, 45, 60, 65, -55, 0),
        "ASMR" to intArrayOf(0, 40, 50, 70, -70, 10)
    )
}

private class Biquad(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) {
    private val B0 = (b0 / a0).toFloat()
    private val B1 = (b1 / a0).toFloat()
    private val B2 = (b2 / a0).toFloat()
    private val A1 = (a1 / a0).toFloat()
    private val A2 = (a2 / a0).toFloat()
    private var z1 = 0f
    private var z2 = 0f

    fun process(x: Float): Float {
        val y = B0 * x + z1
        z1 = B1 * x - A1 * y + z2
        z2 = B2 * x - A2 * y
        return y
    }

    companion object {
        fun lowShelf(fs: Double, f: Double, db: Double): Biquad {
            val a = 10.0.pow(db / 40); val w = 2 * PI * f / fs
            val c = cos(w); val al = sin(w) / 2 * sqrt(2.0); val s = 2 * sqrt(a) * al
            return Biquad(a * ((a + 1) - (a - 1) * c + s), 2 * a * ((a - 1) - (a + 1) * c),
                a * ((a + 1) - (a - 1) * c - s), (a + 1) + (a - 1) * c + s,
                -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - s)
        }

        fun highShelf(fs: Double, f: Double, db: Double): Biquad {
            val a = 10.0.pow(db / 40); val w = 2 * PI * f / fs
            val c = cos(w); val al = sin(w) / 2 * sqrt(2.0); val s = 2 * sqrt(a) * al
            return Biquad(a * ((a + 1) + (a - 1) * c + s), -2 * a * ((a - 1) + (a + 1) * c),
                a * ((a + 1) + (a - 1) * c - s), (a + 1) - (a - 1) * c + s,
                2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - s)
        }

        fun peaking(fs: Double, f: Double, db: Double, q: Double): Biquad {
            val a = 10.0.pow(db / 40); val w = 2 * PI * f / fs
            val c = cos(w); val al = sin(w) / (2 * q)
            return Biquad(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
        }
    }
}

object Fx {
    const val RATE = 44100

    fun process(input: ShortArray, p: FxParams): ShortArray {
        val fs = RATE.toDouble()
        var x = FloatArray(input.size) { input[it] / 32768f }

        // 1. noise gate
        if (p.gateDb > -80) {
            val thr = 10f.pow(p.gateDb / 20f)
            var env = 0f
            var g = 1f
            for (i in x.indices) {
                env = max(abs(x[i]), env * 0.9995f)
                val target = if (env < thr) 0f else 1f
                g += (target - g) * (if (target > g) 0.01f else 0.002f)
                x[i] *= g
            }
        }

        // 2. 3-band EQ (+-12 dB)
        val bassDb = (p.bass - 50) * 0.24; val midDb = (p.mid - 50) * 0.24; val trebDb = (p.treble - 50) * 0.24
        if (p.bass != 50 || p.mid != 50 || p.treble != 50) {
            val lo = Biquad.lowShelf(fs, 200.0, bassDb)
            val mi = Biquad.peaking(fs, 1500.0, midDb, 0.8)
            val hi = Biquad.highShelf(fs, 4000.0, trebDb)
            for (i in x.indices) x[i] = hi.process(mi.process(lo.process(x[i])))
        }

        // 3. pitch (resampling: pitch and speed change together)
        if (p.pitch != 50) {
            val ratio = 2.0.pow((p.pitch - 50) / 50.0)
            val n = (x.size / ratio).toInt()
            val out = FloatArray(n)
            for (i in 0 until n) {
                val pos = i * ratio
                val i0 = pos.toInt()
                val fr = (pos - i0).toFloat()
                val a = x[min(i0, x.size - 1)]
                val b = x[min(i0 + 1, x.size - 1)]
                out[i] = a + (b - a) * fr
            }
            x = out
        }

        // 4. distortion
        if (p.distortion > 0) {
            val d = p.distortion / 100f
            val drive = 1f + d * 8f
            val norm = tanh(drive)
            for (i in x.indices) x[i] = tanh(x[i] * drive) / norm
        }

        // 5. reverb (Schroeder)
        if (p.reverb > 0) {
            val mix = p.reverb / 100f * 0.6f
            val padded = FloatArray(x.size + RATE)
            System.arraycopy(x, 0, padded, 0, x.size)
            x = padded
            val combLens = intArrayOf(1557, 1617, 1491, 1422)
            val combs = Array(4) { FloatArray(combLens[it]) }
            val ci = IntArray(4)
            val apLens = intArrayOf(225, 556)
            val aps = Array(2) { FloatArray(apLens[it]) }
            val ai = IntArray(2)
            for (i in x.indices) {
                val s = x[i]
                var wet = 0f
                for (k in 0 until 4) {
                    val o = combs[k][ci[k]]
                    combs[k][ci[k]] = s + o * 0.8f
                    ci[k] = (ci[k] + 1) % combLens[k]
                    wet += o
                }
                wet *= 0.25f
                for (k in 0 until 2) {
                    val b = aps[k][ai[k]]
                    val y = -wet + b
                    aps[k][ai[k]] = wet + b * 0.5f
                    ai[k] = (ai[k] + 1) % apLens[k]
                    wet = y
                }
                x[i] = s + wet * mix * 3f
            }
        }

        // 6. master gain + soft limiter
        val gain = 10f.pow(p.gainDb / 20f)
        val res = ShortArray(x.size)
        for (i in x.indices) {
            var v = x[i] * gain
            val a = abs(v)
            if (a > 0.9f) v = sign(v) * (0.9f + 0.1f * tanh((a - 0.9f) / 0.1f))
            res[i] = (v.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        return res
    }

    fun wavBytes(pcm: ShortArray): ByteArray {
        val dataLen = pcm.size * 2
        val b = java.nio.ByteBuffer.allocate(44 + dataLen).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt(36 + dataLen); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(RATE); b.putInt(RATE * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataLen)
        for (s in pcm) b.putShort(s)
        return b.array()
    }
}
