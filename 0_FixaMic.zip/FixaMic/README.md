# FIXA MIC (Android)

1. Open this folder in Android Studio (Hedgehog or newer) and let Gradle sync.
2. Run on a phone (or Build > Build APK).
3. Open the app > START. Grant "Display over other apps" and Microphone.
4. Pick WhatsApp / WhatsApp Business (asked only if both are installed).
5. Tap the green square mic at the top-left to open the controls.

Flow: Record > adjust sliders/presets > Play > Share (opens the chosen WhatsApp
share sheet; pick the chat and send as an audio file).

Limits: effects do not work in live WhatsApp calls or in WhatsApp's own
voice-message button. Pitch uses resampling, so speed changes with pitch.
