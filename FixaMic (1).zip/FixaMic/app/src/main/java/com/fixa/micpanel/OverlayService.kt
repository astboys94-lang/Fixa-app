package com.fixa.micpanel

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File

class OverlayService : Service() {

    companion object {
        const val EXTRA_PKG = "pkg"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "fixa_mic"
    }

    private lateinit var wm: WindowManager
    private var iconView: FrameLayout? = null
    private var panelView: View? = null
    private var iconLp: WindowManager.LayoutParams? = null
    private var targetPkg = "com.whatsapp"

    private val fx = FxParams()
    private val recorder = MicRecorder()
    private val player = Player()
    private var raw: ShortArray? = null
    private var recording = false

    private lateinit var status: TextView
    private lateinit var recBtn: TextView
    private val refreshers = ArrayList<() -> Unit>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        intent?.getStringExtra(EXTRA_PKG)?.let { targetPkg = it }
        if (!startAsForeground()) { stopSelf(); return START_NOT_STICKY }
        if (iconView == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            showIcon()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "FIXA MIC", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("FIXA MIC is running")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 30)
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
            true
        } catch (e: Exception) { false }
    }

    // ---------- floating square mic icon ----------
    private fun showIcon() {
        val size = dp(46)
        val box = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#25D366")); cornerRadius = dp(8).toFloat()
            }
            elevation = dp(6).toFloat()
            addView(ImageView(context).apply {
                setImageResource(R.drawable.ic_mic)
                setPadding(dp(9), dp(9), dp(9), dp(9))
            }, FrameLayout.LayoutParams(size, size))
        }
        val lp = WindowManager.LayoutParams(size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0; y = dp(90)
        }
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (moved || Math.abs(mx) > slop || Math.abs(my) > slop) {
                        moved = true
                        lp.x = (sx + mx).toInt(); lp.y = (sy + my).toInt()
                        wm.updateViewLayout(box, lp)
                        if (panelView != null) hidePanel()
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        iconView = box; iconLp = lp
        wm.addView(box, lp)
    }

    private fun togglePanel() { if (panelView == null) showPanel() else hidePanel() }

    private fun hidePanel() {
        panelView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panelView = null
    }

    // ---------- control panel ----------
    private fun label(t: String, size: Float = 12f, color: Int = Color.WHITE) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }

    private fun chip(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(Color.WHITE)
        setPadding(dp(10), dp(6), dp(10), dp(6))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#3B4A54")); cornerRadius = dp(14).toFloat()
        }
        val lp = LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(6)
        layoutParams = lp
        setOnClickListener { onClick() }
    }

    private fun chipRow(items: List<String>, onPick: (String) -> Unit) =
        HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                items.forEach { n -> addView(chip(n) { onPick(n) }) }
            })
        }

    private fun slider(parent: LinearLayout, name: String, min: Int, max: Int,
                       get: () -> Int, set: (Int) -> Unit, unit: String) {
        val tv = label("", 12f)
        val sb = SeekBar(this).apply { this.max = max - min }
        fun upd() { tv.text = "$name: ${get()}$unit" }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                if (user) { set(p + min); upd() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        refreshers.add { sb.progress = get() - min; upd() }
        refreshers.last().invoke()
        parent.addView(tv); parent.addView(sb)
    }

    private fun showPanel() {
        refreshers.clear()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }

        // header
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(label("FIXA MIC", 16f, Color.parseColor("#25D366")),
                LinearLayout.LayoutParams(0, -2, 1f))
            addView(label("\u2715", 18f).apply { setOnClickListener { hidePanel() } })
        })
        status = label("Press Record and speak", 12f, Color.parseColor("#8696A0"))
        col.addView(status)

        // actions
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8))
        }
        recBtn = chip(if (recording) "\u25A0 Stop" else "\u25CF Record") { toggleRecord() }
        actions.addView(recBtn)
        actions.addView(chip("\u25B6 Play") { playIt() })
        actions.addView(chip("Share \u27A4") { shareIt() })
        col.addView(actions)

        // presets
        col.addView(label("Voice changer"))
        col.addView(chipRow(Presets.voices.keys.toList()) { n ->
            val v = Presets.voices[n]!!
            fx.pitch = v[0]; fx.distortion = v[1]; fx.reverb = v[2]
            refreshers.forEach { it() }
        })
        col.addView(label("Presets").apply { setPadding(0, dp(6), 0, 0) })
        col.addView(chipRow(Presets.eq.keys.toList()) { n ->
            val v = Presets.eq[n]!!
            fx.reset()
            fx.gainDb = v[0]; fx.bass = v[1]; fx.mid = v[2]; fx.treble = v[3]
            fx.gateDb = v[4]; fx.reverb = v[5]
            refreshers.forEach { it() }
        })

        // sliders (same controls as the extension)
        val s = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        slider(s, "Master gain", -12, 24, { fx.gainDb }, { fx.gainDb = it }, " dB")
        slider(s, "Pitch", 0, 100, { fx.pitch }, { fx.pitch = it }, "")
        slider(s, "Bass", 0, 100, { fx.bass }, { fx.bass = it }, "")
        slider(s, "Mid", 0, 100, { fx.mid }, { fx.mid = it }, "")
        slider(s, "Treble", 0, 100, { fx.treble }, { fx.treble = it }, "")
        slider(s, "Reverb", 0, 100, { fx.reverb }, { fx.reverb = it }, "")
        slider(s, "Noise gate (-80 = off)", -80, -20, { fx.gateDb }, { fx.gateDb = it }, " dB")
        slider(s, "Distortion", 0, 100, { fx.distortion }, { fx.distortion = it }, "")
        col.addView(s)

        val sv = ScrollView(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2202C33")); cornerRadius = dp(14).toFloat()
            }
            addView(col)
        }

        val dm = resources.displayMetrics
        val w = minOf(dp(320), dm.widthPixels - dp(16))
        val h = (dm.heightPixels * 0.62f).toInt()
        val lp = WindowManager.LayoutParams(w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = minOf((iconLp?.y ?: 0) + dp(52), dm.heightPixels - h - dp(48))
        }
        panelView = sv
        wm.addView(sv, lp)
    }

    // ---------- record / play / share ----------
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun toggleRecord() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Microphone permission missing"); return
        }
        if (!recording) {
            player.stop()
            if (recorder.start()) {
                recording = true
                recBtn.text = "\u25A0 Stop"; status.text = "Recording\u2026"
            } else toast("Could not open the microphone (is another app using it?)")
        } else {
            raw = recorder.stop(); recording = false
            recBtn.text = "\u25CF Record"
            status.text = "Recorded %.1f s".format((raw?.size ?: 0) / Fx.RATE.toFloat())
        }
    }

    private fun processed(): ShortArray? {
        val r = raw
        if (recording) { toast("Stop recording first"); return null }
        if (r == null || r.isEmpty()) { toast("Record something first"); return null }
        return Fx.process(r, fx)
    }

    private fun playIt() {
        Thread {
            val out = processed() ?: return@Thread
            player.play(out)
        }.start()
    }

    private fun shareIt() {
        Thread {
            val out = processed() ?: return@Thread
            val dir = File(cacheDir, "shared").apply { mkdirs() }
            val f = File(dir, "voice_${System.currentTimeMillis()}.wav")
            f.writeBytes(Fx.wavBytes(out))
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "audio/wav"
                putExtra(Intent.EXTRA_STREAM, uri)
                setPackage(targetPkg)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try { startActivity(send) } catch (e: Exception) {
                android.os.Handler(mainLooper).post { toast("Could not open WhatsApp share") }
            }
        }.start()
    }

    override fun onDestroy() {
        if (recording) recorder.stop()
        player.stop()
        hidePanel()
        iconView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        iconView = null
        super.onDestroy()
    }
}
