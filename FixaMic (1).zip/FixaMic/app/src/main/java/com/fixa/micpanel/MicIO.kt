package com.fixa.micpanel

import android.media.*

class MicRecorder {
    private var rec: AudioRecord? = null
    private var thread: Thread? = null
    @Volatile private var running = false
    private val chunks = ArrayList<ShortArray>()

    fun start(): Boolean {
        return try {
            val min = AudioRecord.getMinBufferSize(
                Fx.RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord(MediaRecorder.AudioSource.MIC, Fx.RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return false }
            chunks.clear()
            rec = r
            r.startRecording()
            running = true
            thread = Thread {
                val buf = ShortArray(4096)
                while (running) {
                    val n = r.read(buf, 0, buf.size)
                    if (n > 0) synchronized(chunks) { chunks.add(buf.copyOf(n)) }
                }
            }.also { it.start() }
            true
        } catch (e: Exception) { false }
    }

    fun stop(): ShortArray {
        running = false
        try { thread?.join(500) } catch (_: Exception) {}
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release(); rec = null
        synchronized(chunks) {
            val total = chunks.sumOf { it.size }
            val out = ShortArray(total)
            var o = 0
            for (c in chunks) { System.arraycopy(c, 0, out, o, c.size); o += c.size }
            return out
        }
    }
}

class Player {
    private var track: AudioTrack? = null

    fun play(pcm: ShortArray) {
        stop()
        if (pcm.isEmpty()) return
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(Fx.RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        track = t
        t.play()
    }

    fun stop() {
        try { track?.stop() } catch (_: Exception) {}
        track?.release(); track = null
    }
}
