package com.soundbrowser

import android.content.Context

object Prefs {
    private val defaults = mapOf(
        "src" to 0, "boost" to 35, "eq_on" to 1,
        "eq0" to 0, "eq1" to 0, "eq2" to 0, "eq3" to 0, "eq4" to 0,
        "echo" to 18, "delay" to 100, "reverb" to 5, "room" to 0,
        "clarity" to 0, "balance" to 0, "gate" to 0, "rumble" to 80,
        "speaker" to 0, "safety" to 1, "theme" to 0
    )
    private fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): Int = sp(c).getInt(k, defaults[k] ?: 0)
    fun set(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
}

object AppTheme {
    val colors = intArrayOf(
        0xFFF59E0B.toInt(), 0xFF2DD4BF.toInt(), 0xFFA78BFA.toInt(),
        0xFFA3E635.toInt(), 0xFFFF0000.toInt(), 0xFFFFFFFF.toInt()
    )
    fun accent(c: Context): Int = colors[Prefs.get(c, "theme").coerceIn(0, colors.size - 1)]
}
