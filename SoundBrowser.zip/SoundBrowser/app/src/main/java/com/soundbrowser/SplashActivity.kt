package com.soundbrowser

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar

class SplashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
        }
        val icon = ImageView(this).apply { setImageResource(R.drawable.app_icon) }
        root.addView(icon, LinearLayout.LayoutParams((140 * d).toInt(), (140 * d).toInt()))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(AppTheme.accent(this@SplashActivity))
            progressBackgroundTintList = ColorStateList.valueOf(0xFF333333.toInt())
        }
        val lp = LinearLayout.LayoutParams((220 * d).toInt(), (6 * d).toInt())
        lp.topMargin = (40 * d).toInt()
        root.addView(bar, lp)
        setContentView(root)

        ValueAnimator.ofInt(0, 100).apply {
            duration = 2200
            addUpdateListener { bar.progress = it.animatedValue as Int }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                    finish()
                }
            })
            start()
        }
    }
}
