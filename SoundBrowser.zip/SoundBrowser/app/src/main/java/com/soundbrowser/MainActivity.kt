package com.soundbrowser

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var urlText: TextView
    private val circles = mutableListOf<TextView>()

    private val desktopUA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val sites = listOf(
        Triple("W", "https://web.whatsapp.com", true),
        Triple("M", "https://www.messenger.com", false),
        Triple("I", "https://www.instagram.com", false),
        Triple("F", "https://m.facebook.com", false)
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun circle(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(Color.BLACK)
        layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(6) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        urlText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        bar.addView(urlText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        for ((label, url, desktop) in sites) {
            val c = circle(label)
            c.setOnClickListener { open(url, desktop) }
            circles.add(c)
            bar.addView(c)
        }
        val gear = circle("⚙")
        gear.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        circles.add(gear)
        bar.addView(gear)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.setSupportZoom(true)
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                urlText.text = "🔒  " + (Uri.parse(u).host ?: u)
            }
        }

        root.addView(bar)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        applyTheme()
        open(sites[0].second, true)
    }

    private fun applyTheme() {
        val a = AppTheme.accent(this)
        for (c in circles) {
            c.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(a) }
        }
        urlText.background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setStroke(dp(2), a)
            setColor(0xFF111111.toInt())
        }
    }

    private fun open(url: String, desktop: Boolean) {
        web.settings.userAgentString = if (desktop) desktopUA else null
        urlText.text = "🔒  " + (Uri.parse(url).host ?: url)
        web.loadUrl(url)
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
