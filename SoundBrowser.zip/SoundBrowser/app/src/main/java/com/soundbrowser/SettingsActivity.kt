package com.soundbrowser

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import kotlin.math.roundToInt

class SettingsActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var startBtn: Button
    private var accent = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.BLACK)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(40))
        }
        sv.addView(root)
        setContentView(sv)
        build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun header(s: String) {
        root.addView(label(s, 18f, Color.WHITE, true).apply { setPadding(0, dp(28), 0, dp(6)) })
    }

    private fun slider(key: String, name: String, lo: Int, hi: Int, fmt: (Int) -> String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        val v = label(fmt(Prefs.get(this, key)), 16f, accent)
        row.addView(label(name, 16f, Color.WHITE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(v)
        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = Prefs.get(this, key) - lo
        sb.progressTintList = ColorStateList.valueOf(accent)
        sb.thumbTintList = ColorStateList.valueOf(accent)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                Prefs.set(this@SettingsActivity, key, p + lo)
                v.text = fmt(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(row)
        root.addView(sb)
    }

    private fun toggle(key: String, name: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        row.addView(label(name, 16f, Color.WHITE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = Prefs.get(this, key) == 1
        sw.thumbTintList = ColorStateList.valueOf(accent)
        sw.trackTintList = ColorStateList.valueOf(accent and 0x80FFFFFF.toInt())
        sw.setOnCheckedChangeListener { _, on ->
            Prefs.set(this, key, if (on) 1 else 0)
            if (key == "speaker") AudioService.engine?.takeIf { it.running }?.restart()
        }
        row.addView(sw)
        root.addView(row)
    }

    private fun build() {
        root.removeAllViews()
        accent = AppTheme.accent(this)

        root.addView(label("FIXA SOUND MIC", 24f, Color.WHITE, true))

        startBtn = Button(this).apply {
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(accent) }
            setOnClickListener { toggleAudio() }
        }
        refreshBtn()
        root.addView(startBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(16) })
        root.addView(label("Use headphones to avoid squealing feedback.", 12f, 0xFF999999.toInt()))

        header("THEME")
        val themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in AppTheme.colors.indices) {
            val dot = View(this)
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(AppTheme.colors[i])
                if (i == Prefs.get(this@SettingsActivity, "theme")) setStroke(dp(3), Color.WHITE)
            }
            dot.setOnClickListener { Prefs.set(this, "theme", i); build() }
            themeRow.addView(dot, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) })
        }
        root.addView(themeRow)

        header("SOUND SOURCE")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Back mic", "Phone mic", "Voice", "Raw (loudest noise)"))
        sp.setSelection(Prefs.get(this, "src"))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != Prefs.get(this@SettingsActivity, "src")) {
                    Prefs.set(this@SettingsActivity, "src", pos)
                    AudioService.engine?.takeIf { it.running }?.restart()
                }
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        root.addView(sp)

        header("BOOST")
        slider("boost", "Boost", 0, 100) { "$it%  +${(it * 0.4).roundToInt()} dB" }

        header("EQUALIZER")
        toggle("eq_on", "Equalizer on")
        val names = listOf("60 Hz", "250 Hz", "1 kHz", "4 kHz", "12 kHz")
        for (i in 0 until 5) slider("eq$i", names[i], -12, 12) { "$it dB" }

        header("EFFECTS")
        slider("echo", "Echo", 0, 100) { "$it%" }
        slider("delay", "Delay", 50, 1000) { "$it ms" }
        slider("reverb", "Reverb", 0, 100) { "$it%" }
        slider("room", "Room size", 0, 100) { if (it < 34) "Room" else if (it < 67) "Hall" else "Big hall" }

        header("CLEAN-UP")
        slider("clarity", "Clarity", 0, 100) { if (it == 0) "Off" else "$it%" }
        slider("balance", "Balance", -100, 100) { if (it == 0) "Centre" else if (it < 0) "L ${-it}" else "R $it" }
        slider("gate", "Noise gate", 0, 100) { if (it == 0) "Off" else "$it%" }
        slider("rumble", "Rumble filter", 0, 400) { if (it < 20) "Off" else "$it Hz" }

        header("OUTPUT")
        toggle("speaker", "Force phone speaker")
        toggle("safety", "Headphone safety")
    }

    private fun refreshBtn() {
        startBtn.text = if (AudioService.engine?.running == true) "STOP" else "START"
    }

    private fun toggleAudio() {
        if (AudioService.engine?.running == true) {
            stopService(Intent(this, AudioService::class.java))
            startBtn.text = "START"
            return
        }
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        startAudio()
    }

    private fun startAudio() {
        startForegroundService(Intent(this, AudioService::class.java))
        startBtn.text = "STOP"
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startAudio()
    }

    override fun onResume() {
        super.onResume()
        if (::startBtn.isInitialized) refreshBtn()
    }
}
