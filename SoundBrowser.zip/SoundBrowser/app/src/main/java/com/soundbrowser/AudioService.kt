package com.soundbrowser

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class AudioService : Service() {
    companion object {
        var engine: AudioEngine? = null
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("audio", "Sound boost", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "audio")
            .setContentTitle("FIXA SOUND MIC running")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        val e = engine ?: AudioEngine(applicationContext).also { engine = it }
        e.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        engine?.stop()
        super.onDestroy()
    }
}
