package com.soundbrowser

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

class Biquad {
    private var b0 = 1f; private var b1 = 0f; private var b2 = 0f
    private var a1 = 0f; private var a2 = 0f
    private var z1 = 0f; private var z2 = 0f

    fun process(x: Float): Float {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }

    fun peaking(sr: Int, f: Double, gainDb: Double, q: Double) {
        val a = 10.0.pow(gainDb / 40.0)
        val w = 2 * PI * f / sr
        val alpha = sin(w) / (2 * q)
        val c = cos(w)
        val a0 = 1 + alpha / a
        b0 = ((1 + alpha * a) / a0).toFloat()
        b1 = ((-2 * c) / a0).toFloat()
        b2 = ((1 - alpha * a) / a0).toFloat()
        a1 = ((-2 * c) / a0).toFloat()
        a2 = ((1 - alpha / a) / a0).toFloat()
    }

    fun highpass(sr: Int, f: Double) {
        val w = 2 * PI * f / sr
        val alpha = sin(w) / (2 * 0.707)
        val c = cos(w)
        val a0 = 1 + alpha
        b0 = (((1 + c) / 2) / a0).toFloat()
        b1 = ((-(1 + c)) / a0).toFloat()
        b2 = b0
        a1 = ((-2 * c) / a0).toFloat()
        a2 = ((1 - alpha) / a0).toFloat()
    }
}

class AudioEngine(private val ctx: Context) {
    @Volatile var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread { loop() }.also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(800)
        thread = null
    }

    fun restart() { stop(); start() }

    private fun p(k: String) = Prefs.get(ctx, k)

    private fun loop() {
        val sr = 44100
        val frame = 1024
        val source = when (p("src")) {
            0 -> MediaRecorder.AudioSource.CAMCORDER
            1 -> MediaRecorder.AudioSource.MIC
            2 -> MediaRecorder.AudioSource.VOICE_RECOGNITION
            else -> MediaRecorder.AudioSource.UNPROCESSED
        }
        val minIn = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(source, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minIn, frame * 4))
        } catch (e: Exception) { running = false; return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); running = false; return }

        val minOut = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            )
            .setBufferSizeInBytes(max(minOut, frame * 8))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()

        if (p("speaker") == 1) {
            val am = ctx.getSystemService(AudioManager::class.java)
            am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                ?.let { track.preferredDevice = it }
        }

        val inBuf = ShortArray(frame)
        val out = ShortArray(frame * 2)
        val hp = Biquad()
        val eq = Array(5) { Biquad() }
        val freqs = doubleArrayOf(60.0, 250.0, 1000.0, 4000.0, 12000.0)
        val delayBuf = FloatArray(sr)
        var dpos = 0
        val combLen = intArrayOf(1557, 1617, 1491, 1422)
        val combs = Array(4) { FloatArray(combLen[it]) }
        val cpos = IntArray(4)
        var env = 0f
        var gateG = 1f

        rec.startRecording()
        track.play()

        while (running) {
            val n = rec.read(inBuf, 0, frame)
            if (n <= 0) continue

            val gain = 10.0.pow(p("boost") * 0.4 / 20.0).toFloat()
            val rumble = p("rumble")
            val hpOn = rumble >= 20
            if (hpOn) hp.highpass(sr, rumble.toDouble())
            val eqOn = p("eq_on") == 1
            if (eqOn) {
                for (i in 0 until 5) {
                    var g = p("eq$i").toDouble()
                    if (i == 3) g += p("clarity") * 0.1
                    eq[i].peaking(sr, freqs[i], g, 1.0)
                }
            }
            val gateThr = p("gate") / 100f * 0.05f
            val echoSamples = (p("delay") * sr / 1000).coerceIn(1, sr - 1)
            val echoAmt = p("echo") / 100f
            val revMix = p("reverb") / 100f
            val fb = 0.6f + p("room") / 100f * 0.35f
            val ceiling = if (p("safety") == 1) 0.35f else 0.98f
            val bal = p("balance") / 100f
            val lg = if (bal > 0) 1f - bal else 1f
            val rg = if (bal < 0) 1f + bal else 1f

            for (i in 0 until n) {
                var x = inBuf[i] / 32768f
                if (hpOn) x = hp.process(x)
                if (gateThr > 0f) {
                    val a = abs(x)
                    env = if (a > env) a else env * 0.9995f
                    val target = if (env > gateThr) 1f else 0f
                    gateG += (target - gateG) * 0.01f
                    x *= gateG
                }
                if (eqOn) for (bq in eq) x = bq.process(x)
                x *= gain

                var rd = dpos - echoSamples
                if (rd < 0) rd += sr
                val d = delayBuf[rd]
                var y = x + d * echoAmt
                delayBuf[dpos] = x + d * echoAmt * 0.5f
                dpos = (dpos + 1) % sr

                var r = 0f
                for (c in 0 until 4) {
                    val buf = combs[c]
                    val o = buf[cpos[c]]
                    buf[cpos[c]] = y + o * fb
                    cpos[c] = (cpos[c] + 1) % buf.size
                    r += o
                }
                y += r * 0.25f * revMix

                y = ceiling * tanh(y / ceiling)
                out[i * 2] = (y * lg * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()
                out[i * 2 + 1] = (y * rg * 32767f).coerceIn(-32768f, 32767f).toInt().toShort()
            }
            track.write(out, 0, n * 2)
        }

        try { rec.stop() } catch (e: Exception) {}
        rec.release()
        try { track.stop() } catch (e: Exception) {}
        track.release()
        running = false
    }
}
