package com.fixa.micpanel

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val apps = linkedMapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#111B21"))
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "FIXA MIC"; textSize = 30f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Start \u2192 WhatsApp \u2192 \u0b87\u0b9f\u0ba4\u0bc1 \u0bae\u0bc7\u0bb2\u0bcd \u0bae\u0bc2\u0bb2\u0bc8\u0baf\u0bbf\u0bb2\u0bcd \u0bae\u0bc8\u0b95\u0bcd \u0baa\u0b9f\u0bcd\u0b9f\u0ba9\u0bcd"
            textSize = 14f; setTextColor(Color.parseColor("#8696A0"))
            gravity = Gravity.CENTER; setPadding(0, 16, 0, 64)
        })
        root.addView(Button(this).apply {
            text = "START"; textSize = 22f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#25D366")); cornerRadius = 120f
            }
            setPadding(96, 48, 96, 48)
            setOnClickListener { startFlow() }
        })
        root.addView(Button(this).apply {
            text = "STOP"; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#3B4A54")); cornerRadius = 120f
            }
            setOnClickListener {
                startService(Intent(this@MainActivity, OverlayService::class.java)
                    .setAction(OverlayService.ACTION_STOP))
            }
        })
        setContentView(root)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps', then press START again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), 1)
            return
        }
        pickAndLaunch()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            pickAndLaunch()
        else Toast.makeText(this, "Microphone permission is required", Toast.LENGTH_LONG).show()
    }

    private fun installed(): List<String> =
        apps.keys.filter { packageManager.getLaunchIntentForPackage(it) != null }

    private fun pickAndLaunch() {
        val list = installed()
        when (list.size) {
            0 -> Toast.makeText(this, "WhatsApp is not installed", Toast.LENGTH_LONG).show()
            1 -> launch(list[0])
            else -> AlertDialog.Builder(this)
                .setTitle("\u0b8e\u0ba8\u0bcd\u0ba4 WhatsApp-\u0b90 \u0ba4\u0bbf\u0bb1\u0b95\u0bcd\u0b95\u0bb5\u0bc7\u0ba3\u0bcd\u0b9f\u0bc1\u0bae\u0bcd?")
                .setItems(list.map { apps[it] }.toTypedArray()) { _, i -> launch(list[i]) }
                .show()
        }
    }

    private fun launch(pkg: String) {
        val svc = Intent(this, OverlayService::class.java).putExtra(OverlayService.EXTRA_PKG, pkg)
        startForegroundService(svc)
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }
}
